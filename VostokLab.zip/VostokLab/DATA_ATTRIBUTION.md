# Источник данных и условия использования

De Mulder, Tine; Adams, Heleen; Dewit, Tijl; Molenaers, Guy; Van Campenhout, Anja; Desloovere, Kaat (2024).
**A Comparison of the Immediate Effects of Verbal and Virtual Reality Feedback on Gait in Children with Cerebral Palsy**.
KU Leuven Research Data Repository, Version 1.

DOI: https://doi.org/10.48804/JUNNWW

Лицензия: **Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)**.

Этот прототип использует оригинальные CSV без изменения числовых измерений.
Программный код парсера обрабатывает, агрегирует и визуализирует данные.
Соблюдайте некоммерческий характер использования, указывайте авторов и ссылку на источник;
при распространении адаптированных данных соблюдайте ShareAlike.

Оригинальный README доступен в предоставленном архиве `gait-cp-dataset.zip`.
