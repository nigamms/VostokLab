import java.util.Properties
import java.io.StringReader

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

// Build-time OpenRouter configuration. No menu, no local server.
// Three supported locations (priority): project/ai.properties, project/app/ai.properties,
// project/local.properties. Print source presence only; NEVER log the key itself.
val configPaths = listOf(rootProject.file("ai.properties"),
    project.file("ai.properties"), rootProject.file("local.properties"))
val aiConfig = Properties()
val configSources = mutableListOf<String>()
configPaths.reversed().forEach { f ->
    if (f.isFile) {
        val source = f.readText(Charsets.UTF_8).removePrefix("\uFEFF")
        val parsed = Properties().apply { load(StringReader(source)) }
        aiConfig.putAll(parsed)
        configSources += f.absolutePath
    }
}
fun readSecret(name: String): String {
    val fromEnvironment = System.getenv(name).orEmpty().trim()
    val raw = (if (fromEnvironment.isNotBlank()) fromEnvironment else aiConfig.getProperty(name).orEmpty()).trim()
    return raw.removeSurrounding("\"").removeSurrounding("'").trim()
}
fun validKey(key: String) = key.isNotBlank() && !key.startsWith("PASTE_", ignoreCase = true)
    && !key.contains("ТВОЙ_КЛЮЧ", ignoreCase = true) && !key.contains("YOUR_KEY", ignoreCase = true)
fun kotlinQuoted(value: String): String = "\"" + value
    .replace("\\", "\\\\").replace("\"", "\\\"")
    .replace("\r", "").replace("\n", "") + "\""

val textKey = readSecret("OPENROUTER_API_KEY")
val voiceKey = readSecret("OPENAI_API_KEY")
val textModel = readSecret("OPENROUTER_MODEL").ifBlank { "openai/gpt-4.1-mini" }

// Clear diagnosis during APK build; no need to learn about a missing key on the phone.
val verifyAiConfig = tasks.register("verifyAiConfig") {
    doLast {
        println("VostokLab AI configuration: " +
            (if (validKey(textKey)) "OpenRouter configured" else "OpenRouter MISSING"))
        println("VostokLab config files: " +
            if (configSources.isEmpty()) "none" else configSources.joinToString("; "))
        println("VostokLab voice: " + if (validKey(voiceKey)) "OpenAI Live configured" else "Android fallback")
        if (!validKey(textKey)) throw org.gradle.api.GradleException(
            "VostokLab: OPENROUTER_API_KEY is empty. Add it to " +
            rootProject.file("ai.properties").absolutePath +
            " (no quotes), then Build > Clean Project > Build APK(s). " +
            "The key must be set BEFORE APK assembly.")
    }
}

android {
    namespace = "kz.vostoklab.app"
    compileSdk = 37
    defaultConfig {
        applicationId = "kz.vostoklab.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 11
        versionName = "5.8.0"
        buildConfigField("String", "OPENROUTER_API_KEY", kotlinQuoted(textKey))
        buildConfigField("String", "OPENROUTER_MODEL", kotlinQuoted(textModel))
        buildConfigField("String", "OPENAI_API_KEY", kotlinQuoted(voiceKey))
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.09.00")
    implementation(composeBom)
    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.10.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    debugImplementation("androidx.compose.ui:ui-tooling")
}

// Verify the local config before building an APK. Sync still works without a key.
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(verifyAiConfig) }

// Important for reproducible BuildConfig when the local key is edited.
tasks.matching { it.name.startsWith("generate") && it.name.endsWith("BuildConfig") }
    .configureEach { inputs.files(configPaths) }
