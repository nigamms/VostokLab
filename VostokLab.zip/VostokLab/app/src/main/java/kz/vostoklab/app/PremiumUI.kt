package kz.vostoklab.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import kotlin.math.max

// Precision / motion — a coherent visual system, not a collection of demo widgets.
private val Midnight = Color(0xFF153844)
private val DeepBlue = Color(0xFF143B4D)
private val Cyan = Color(0xFF2ACBB5)
private val Mint = Color(0xFF0A9C89)
private val Indigo = Color(0xFF697EED)
private val Apricot = Color(0xFFF5A769)
private val MutedInk = Color(0xFF647B83)
private val SurfaceWhite = Color(0xFFFFFFFF)
private val OceanLight = Color(0xFFE7F8F3)
private val ConditionColorsPremium = mapOf(
    WalkCondition.BASELINE to Indigo,
    WalkCondition.VERBAL to Apricot,
    WalkCondition.VR to Mint
)
private fun tr(lang: String, ru: String, kk: String) = if (lang == "kk") kk else ru
private fun number(value: Double?, digits: Int = 2): String = value?.format(digits) ?: "—"
private fun signed(value: Double?, digits: Int = 2): String = when {
    value == null -> "—"
    value > 0 -> "+${value.format(digits)}"
    else -> value.format(digits)
}

@Composable
fun PremiumLogo(modifier: Modifier = Modifier, dimension: Int = 44) {
    Box(modifier.size(dimension.dp).clip(RoundedCornerShape((dimension * .31).dp))
        .background(Brush.linearGradient(listOf(Cyan, Mint, Color(0xFF008A91)))),
        contentAlignment = Alignment.Center) {
        Canvas(Modifier.size((dimension * .60).dp)) {
            val w = size.width; val h = size.height
            val path = Path().apply {
                moveTo(w * .04f, h * .52f)
                lineTo(w * .26f, h * .52f)
                lineTo(w * .37f, h * .20f)
                lineTo(w * .55f, h * .79f)
                lineTo(w * .70f, h * .42f)
                lineTo(w * .96f, h * .42f)
            }
            drawPath(path, Color.White, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
            drawCircle(Color.White, radius = 2.8.dp.toPx(), center = Offset(w * .96f, h * .42f))
        }
    }
}

@Composable
fun PremiumHeader(lang: String, selected: String, tab: Int, hasData: Boolean,
                  onSettings: () -> Unit, onHelp: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val isDark = scheme.background.red < .2f
    Surface(color = scheme.surface, shadowElevation = 1.dp,
        border = BorderStroke(1.dp, scheme.outlineVariant.copy(alpha = .5f))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 17.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically) {
            PremiumLogo(dimension = 42)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("VostokLab", color = scheme.onSurface, fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold, letterSpacing = (-.7).sp)
                Text(tr(lang, "Интеллектуальный анализ движения", "Қозғалысты интеллектуалды талдау"),
                    color = scheme.onSurfaceVariant, fontSize = 11.sp,
                    fontWeight = FontWeight.Medium, letterSpacing = .2.sp, maxLines = 1)
            }
            if (hasData) {
                Surface(color = Mint.copy(alpha = if (isDark) .2f else .10f),
                    shape = RoundedCornerShape(100.dp)) {
                    Row(Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(Mint))
                        Spacer(Modifier.width(5.dp))
                        Text(tr(lang, "Готово", "Дайын"), color = if (isDark) Cyan else Mint,
                            fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.width(5.dp))
            }
            IconButton(onClick = onHelp,
                modifier = Modifier.size(40.dp).clip(RoundedCornerShape(13.dp))) {
                Icon(Icons.Default.HelpOutline, tr(lang, "Помощь", "Көмек"),
                    tint = scheme.primary, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(5.dp))
            IconButton(onClick = onSettings,
                modifier = Modifier.size(40.dp).clip(RoundedCornerShape(13.dp))
                    .background(scheme.surfaceVariant)) {
                Icon(Icons.Default.Tune, tr(lang, "Настройки", "Баптау"), tint = scheme.primary,
                    modifier = Modifier.size(21.dp))
            }
        }
    }
}

@Composable
fun PremiumBottomBar(lang: String, selected: Int, hasData: Boolean, onSelect: (Int) -> Unit) {
    val navigation = listOf(
        Triple(Icons.Default.Home, tr(lang, "Главная", "Басты"), 0),
        Triple(Icons.Default.PeopleOutline, tr(lang, "Участники", "Қатысушы"), 1),
        Triple(Icons.Default.ShowChart, tr(lang, "Анализ", "Талдау"), 2),
        Triple(Icons.Default.AutoAwesome, tr(lang, "ИИ", "ЖИ"), 3)
    )
    Surface(shadowElevation = 9.dp, color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .65f))) {
        Row(Modifier.fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            navigation.forEach { (icon, title, index) ->
                val locked = index != 0 && !hasData
                val active = selected == index && !locked
                val activeColor by animateColorAsState(
                    if (locked) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .45f)
                    else if (active) Mint else MaterialTheme.colorScheme.onSurfaceVariant,
                    label = "Navigation color")
                Column(Modifier.weight(1f).clip(RoundedCornerShape(17.dp))
                    .background(if (active) Mint.copy(alpha = .10f) else Color.Transparent)
                    // Locked destinations still explain why they are unavailable when tapped.
                    .clickable { onSelect(index) }.padding(vertical = 9.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Box(Modifier.fillMaxWidth().height(24.dp), contentAlignment = Alignment.Center) {
                        Icon(icon, title, tint = activeColor, modifier = Modifier.size(22.dp))
                        if (locked) Icon(Icons.Default.Lock, null,
                            tint = activeColor, modifier = Modifier.align(Alignment.TopEnd)
                                .padding(end = 17.dp).size(11.dp))
                    }
                    Text(title, color = activeColor, fontSize = 10.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontWeight = if (active) FontWeight.Bold else FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun MiniEyebrow(text: String, modifier: Modifier = Modifier, color: Color = MutedInk) {
    Text(text.uppercase(), modifier = modifier, color = color, fontSize = 10.sp,
        fontWeight = FontWeight.ExtraBold, letterSpacing = 1.2.sp)
}

@Composable
private fun PremiumCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Surface(modifier.fillMaxWidth(), shape = RoundedCornerShape(23.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .70f)),
        shadowElevation = 1.dp) {
        Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
private fun PremiumSection(title: String, hint: String? = null, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onSurface, letterSpacing = (-.4).sp)
            if (hint != null) Text(hint, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (action != null && onAction != null) {
            TextButton(onClick = onAction, contentPadding = PaddingValues(horizontal = 6.dp)) {
                Text(action, fontSize = 12.sp, color = Mint, fontWeight = FontWeight.Bold)
                Icon(Icons.Default.ChevronRight, null, tint = Mint, modifier = Modifier.size(17.dp))
            }
        }
    }
}

@Composable
private fun StatePill(label: String, accent: Color, modifier: Modifier = Modifier) {
    Row(modifier.clip(RoundedCornerShape(80.dp)).background(accent.copy(alpha = .12f))
        .padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
        Spacer(Modifier.width(6.dp))
        Text(label, color = accent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

@Composable
private fun PremiumHero(lang: String, isEmpty: Boolean, onClick: () -> Unit) {
    val isDark = MaterialTheme.colorScheme.background.red < .2f
    val heroInk = if (isDark) Color.White else Color(0xFF143D43)
    Box(Modifier.fillMaxWidth().height(if (isEmpty) 252.dp else 218.dp)
        .clip(RoundedCornerShape(24.dp))
        .background(Brush.linearGradient(if (isDark)
            listOf(Color(0xFF10323D), Color(0xFF0A5558), Color(0xFF0C7771))
            else listOf(Color(0xFFE7F8F2), Color(0xFFCBF1E7), Color(0xFFBDE9EF))))) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(Mint.copy(alpha = if (isDark) .20f else .08f), radius = size.width * .64f,
                center = Offset(size.width * 1.07f, size.height * .18f))
            drawCircle(Color.White.copy(alpha = .045f), radius = size.width * .30f,
                center = Offset(size.width * .99f, size.height * .95f))
            for (i in 0..8) {
                val x = size.width * (.49f + i * .07f)
                drawLine(heroInk.copy(alpha = .07f), Offset(x, 0f), Offset(x, size.height), 1.dp.toPx())
            }
            for (i in 1..6) {
                val y = size.height * i / 7f
                drawLine(heroInk.copy(alpha = .07f), Offset(size.width * .46f, y), Offset(size.width, y), 1.dp.toPx())
            }
            val wave = Path()
            for (i in 0..100) {
                val x = size.width * (.45f + .50f * i / 100f)
                val t = i / 100f
                val sin = kotlin.math.sin(t.toDouble() * 2.0 * Math.PI).toFloat()
                val y = size.height * (.56f - .24f * sin + .06f * kotlin.math.sin(4.0 * Math.PI * t).toFloat())
                if (i == 0) wave.moveTo(x, y) else wave.lineTo(x, y)
            }
            drawPath(wave, Mint.copy(alpha = .85f), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
            drawCircle(Mint, radius = 4.dp.toPx(), center = Offset(size.width * .95f, size.height * .56f))
        }
        Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = (if (isDark) Color.White else Mint).copy(alpha = .13f),
                        shape = RoundedCornerShape(50.dp)) {
                        Row(Modifier.padding(horizontal = 11.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, null, tint = if (isDark) Cyan else Mint, modifier = Modifier.size(13.dp))
                            Spacer(Modifier.width(5.dp))
                            Text("AI & MEDICINE 2026", color = heroInk, fontWeight = FontWeight.Bold,
                                fontSize = 10.sp, letterSpacing = .7.sp)
                        }
                    }
                }
                Spacer(Modifier.height(3.dp))
                Text(tr(lang, "Движение —\nв деталях.", "Қозғалыс —\nәр бөлшекте."),
                    fontSize = 29.sp, lineHeight = 32.sp, color = heroInk,
                    fontWeight = FontWeight.ExtraBold, letterSpacing = (-.9).sp)
                Text(tr(lang, "Три условия ходьбы. Один точный взгляд на данные.",
                    "Жүрістің үш шарты. Деректерге бір нақты көзқарас."),
                    fontSize = 12.sp, lineHeight = 17.sp,
                    color = if (isDark) Color(0xFFCEE9E5) else Color(0xFF456970),
                    modifier = Modifier.fillMaxWidth(.77f))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(color = if (isDark) Color.White else Mint, shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.then(coachOutline(HelpSection.HOME, 17))
                        .clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick)) {
                    Row(Modifier.padding(horizontal = 15.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (isEmpty) Icons.Default.UploadFile else Icons.Default.Insights,
                            null, tint = if (isDark) Midnight else Color.White, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(7.dp))
                        Text(tr(lang, if (isEmpty) "Загрузить данные" else "Открыть анализ",
                            if (isEmpty) "Дерек жүктеу" else "Талдауды ашу"),
                            color = if (isDark) Midnight else Color.White, fontSize = 12.sp,
                            fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, detail: String, color: Color = Mint) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(39.dp).clip(RoundedCornerShape(13.dp)).background(color.copy(alpha = .12f)),
            contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun PremiumEmptyHome(lang: String, count: Int, message: String,
                     onImport: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(17.dp),
        verticalArrangement = Arrangement.spacedBy(17.dp)) {
        MiniEyebrow(tr(lang, "Новая медицинская аналитика", "Жаңа медициналық талдау"))
        PremiumHero(lang, true, onImport)
        CoachCallout(lang, HelpSection.HOME, arrowAtStart = true)
        PremiumCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(47.dp).clip(RoundedCornerShape(16.dp))
                    .background(OceanLight), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.FolderOpen, null, tint = Mint, modifier = Modifier.size(25.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(tr(lang, "Новое исследование", "Жаңа зерттеу"),
                        fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                    Text(tr(lang, "Выберите ZIP или шесть CSV", "ZIP не алты CSV таңдаңыз"),
                        color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                }
                StatePill("$count / 6", if (count == 0) Apricot else Mint)
            }
            Text(tr(lang,
                if (count == 0) "Загрузите набор исследования, чтобы открыть участников, графики и ИИ."
                else "Загружено $count из 6 файлов. Для анализа нужен полный набор.",
                if (count == 0) "Қатысушыларды, графиктерді және ЖИ-ды ашу үшін деректерді жүктеңіз."
                else "$count / 6 файл жүктелді. Талдау үшін толық жинақ керек."),
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LinearProgressIndicator(progress = { count / 6f },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(12.dp)),
                color = Mint, trackColor = MaterialTheme.colorScheme.outlineVariant)
            Button(onClick = onImport, modifier = Modifier.fillMaxWidth().height(49.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Mint),
                shape = RoundedCornerShape(15.dp)) {
                Icon(Icons.Default.Add, null, modifier = Modifier.size(19.dp))
                Spacer(Modifier.width(7.dp))
                Text(tr(lang, if (count == 0) "Выбрать файлы" else "Добавить недостающие",
                    if (count == 0) "Файлдарды таңдау" else "Жетіспейтінін қосу"),
                    fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(5.dp))
                Icon(Icons.Default.ArrowForward, null, modifier = Modifier.size(17.dp))
            }
            if (message.isNotBlank()) Text(message, fontSize = 12.sp, color = Mint)
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = .08f))
            .padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Lock, null, tint = Mint, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Text(tr(lang,
                "Разделы ниже откроются после импорта. Нажатие на вкладку покажет подсказку.",
                "Төмендегі бөлімдер импорттан кейін ашылады. Бөлімді түртсеңіз, нұсқау шығады."),
                modifier = Modifier.weight(1f), fontSize = 11.sp,
                lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurface)
        }
        PremiumSection(tr(lang, "После загрузки доступны", "Жүктегеннен кейін қолжетімді"))
        PremiumCard {
            FeatureRow(Icons.Default.StackedLineChart,
                tr(lang, "Сравнение 3 условий", "3 жағдайды салыстыру"),
                "Baseline • Verbal • VR", Indigo)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            FeatureRow(Icons.Default.AutoAwesome,
                tr(lang, "ИИ-интерпретация", "ЖИ түсіндіру"),
                tr(lang, "На основе загруженных данных", "Жүктелген деректер негізінде"))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            FeatureRow(Icons.Default.PictureAsPdf,
                tr(lang, "Отчёт для врача", "Дәрігерге есеп"),
                tr(lang, "Графики и статистика в PDF", "PDF ішіндегі график пен статистика"), Apricot)
        }
        ResearchHelpAccordions(lang, HelpSection.HOME)
        TextButton(onClick = onSettings, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Icon(Icons.Default.Language, null, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(5.dp))
            Text(tr(lang, "Язык и оформление", "Тіл және көрініс"), fontSize = 12.sp)
        }
        Spacer(Modifier.height(7.dp))
    }
}

@Composable
private fun DataImportCard(lang: String, count: Int, onImport: () -> Unit, message: String) {
    PremiumCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.DatasetLinked, null, tint = Mint, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(tr(lang, "Источники данных", "Дереккөздер"), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                Text(tr(lang, "Загружено CSV: $count из 6", "Жүктелген CSV: $count / 6"),
                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Surface(shape = RoundedCornerShape(12.dp), color = Mint.copy(alpha = .12f),
                modifier = Modifier.clickable { onImport() }) {
                Icon(Icons.Default.Add, tr(lang,"Добавить", "Қосу"), tint = Mint,
                    modifier = Modifier.padding(10.dp).size(20.dp))
            }
        }
        LinearProgressIndicator(progress = { count / 6f }, modifier = Modifier.fillMaxWidth().height(5.dp)
            .clip(RoundedCornerShape(100.dp)), color = Mint,
            trackColor = MaterialTheme.colorScheme.outlineVariant)
        if (message.isNotBlank()) Text(message, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun DataStat(value: String, label: String, accent: Color, modifier: Modifier) {
    Surface(modifier, shape = RoundedCornerShape(19.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .75f))) {
        Column(Modifier.padding(horizontal = 11.dp, vertical = 15.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Box(Modifier.size(20.dp).clip(RoundedCornerShape(7.dp)).background(accent.copy(alpha = .14f)),
                contentAlignment = Alignment.Center) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(accent))
            }
            Text(value, fontSize = 22.sp, lineHeight = 24.sp, fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-.9).sp)
            Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ConditionLine(condition: WalkCondition, record: GaitRecord?, lang: String) {
    val accent = ConditionColorsPremium.getValue(condition)
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(12.dp))
            .background(accent.copy(alpha = .12f)), contentAlignment = Alignment.Center) {
            Icon(when (condition) {
                WalkCondition.BASELINE -> Icons.Default.DirectionsWalk
                WalkCondition.VERBAL -> Icons.Default.RecordVoiceOver
                WalkCondition.VR -> Icons.Default.ViewInAr
            }, null, tint = accent, modifier = Modifier.size(19.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(condition.fileSuffix, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(tr(lang, "Циклов: ${record?.cycleCount ?: 0}", "Цикл: ${record?.cycleCount ?: 0}"),
                fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text(number(record?.metric("GPS_a")), fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.width(4.dp))
        Text("GPS", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
    }
}

@Composable
private fun PremiumGpsCompareCard(base: GaitRecord?, verbal: GaitRecord?, vr: GaitRecord?, lang: String) {
    val observations = listOf(
        Triple(WalkCondition.BASELINE, base?.metric("GPS_a"), Indigo),
        Triple(WalkCondition.VERBAL, verbal?.metric("GPS_a"), Apricot),
        Triple(WalkCondition.VR, vr?.metric("GPS_a"), Mint)
    )
    val maximum = observations.mapNotNull { it.second }.maxOrNull()?.coerceAtLeast(.001) ?: 1.0
    val baseValue = base?.metric("GPS_a")
    val vrValue = vr?.metric("GPS_a")
    val difference = GaitAnalytics.delta(baseValue, vrValue)
    val percent = if (baseValue != null && vrValue != null && abs(baseValue) > .000001)
        100.0 * (vrValue - baseValue) / abs(baseValue) else null
    PremiumCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                .background(Mint.copy(alpha = .12f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Insights, null, tint = Mint)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(tr(lang, "Сравнение GPS", "GPS салыстыру"),
                    fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                Text(tr(lang, "Средние значения по условиям", "Жағдайлар бойынша орташа мәндер"),
                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            StatePill("3 × GPS", Mint)
        }
        observations.forEach { (condition, value, color) ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(color))
                Spacer(Modifier.width(8.dp))
                Text(condition.fileSuffix, modifier = Modifier.width(66.dp),
                    fontSize = 11.sp, fontWeight = FontWeight.Bold)
                LinearProgressIndicator(progress = { ((value ?: 0.0) / maximum).toFloat().coerceIn(0f, 1f) },
                    modifier = Modifier.weight(1f).height(9.dp).clip(RoundedCornerShape(100.dp)),
                    color = color, trackColor = MaterialTheme.colorScheme.outlineVariant)
                Spacer(Modifier.width(9.dp))
                Text(number(value), modifier = Modifier.width(43.dp), fontSize = 12.sp,
                    textAlign = TextAlign.End, fontWeight = FontWeight.Bold)
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr(lang, "VR − Baseline", "VR − Baseline"),
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(tr(lang, "Изменение описательное, не оценка лечения",
                    "Өзгеріс сипаттамалық, ем бағасы емес"),
                    fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(signed(difference), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface)
                Text((if (percent == null) "—" else signed(percent, 1) + "%"),
                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(tr(lang,
            "GPS показывает отклонение от нормативного шаблона. Нельзя делать вывод об эффективности терапии по одному условию или среднему значению.",
            "GPS қалыпты жүріс үлгісінен ауытқуды сипаттайды. Бір жағдай немесе орташа мән бойынша ем тиімділігі туралы қорытынды жасауға болмайды."),
            fontSize = 11.sp, lineHeight = 16.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun PremiumDashboard(data: GaitDataset, selected: String, lang: String,
                     onAnalyze: () -> Unit, onPatients: () -> Unit, onImport: () -> Unit, importMessage: String) {
    val base = data.find(selected, WalkCondition.BASELINE)
    val verbal = data.find(selected, WalkCondition.VERBAL)
    val vr = data.find(selected, WalkCondition.VR)
    val diff = GaitAnalytics.delta(base?.metric("GPS_a"), vr?.metric("GPS_a"))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(17.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        MiniEyebrow(tr(lang, "Обзор исследования", "Зерттеу шолуы"))
        PremiumHero(lang, false, onAnalyze)
        CoachCallout(lang, HelpSection.HOME, imported = true, arrowAtStart = true)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            DataStat("${data.subjects.size}", tr(lang, "Участники", "Қатысушы"), Indigo, Modifier.weight(1f))
            DataStat("${data.totalCycles}", tr(lang, "Циклы шага", "Қадам циклі"), Mint, Modifier.weight(1f))
            DataStat("${data.loadedFiles}/6", "CSV", Apricot, Modifier.weight(1f))
        }
        DataImportCard(lang, data.loadedFiles, onImport, importMessage)
        PremiumSection(tr(lang, "Выбранный участник", "Таңдалған қатысушы"),
            tr(lang, "Одна сторона исследования", "Зерттеудің бір жағы"),
            tr(lang, "Сменить", "Өзгерту"), onPatients)
        PremiumCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(50.dp).clip(RoundedCornerShape(16.dp)).background(Indigo.copy(alpha = .12f)),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PersonOutline, null, tint = Indigo, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(selected, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                    Text(tr(lang, "Сторона: ", "Жағы: ") + (base?.side ?: "—"),
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StatePill(tr(lang, "Исследование", "Зерттеу"), Mint)
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            WalkCondition.entries.forEach { condition ->
                ConditionLine(condition, data.find(selected, condition), lang)
            }
        }
        PremiumSection(tr(lang, "Кривые движения", "Қозғалыс қисықтары"),
            tr(lang, "Средние кривые • 0–100% цикла", "Орташа қисық • циклдің 0–100%"),
            tr(lang, "Подробнее", "Толығырақ"), onAnalyze)
        PremiumCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr(lang, "Угол бедра", "Сан бұрышы"), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text("aSagH · °", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(Icons.Default.ShowChart, null, tint = Mint)
            }
            PremiumCurve(listOfNotNull(base, verbal, vr).map { it.condition to it.curves.getValue("aSagH") },
                Modifier.fillMaxWidth().height(167.dp), lang = lang)
            ConditionLegend()
        }
        PremiumSection(tr(lang, "Сигнал исследования", "Зерттеу сигналы"),
            tr(lang, "Описательное сравнение трёх условий", "Үш жағдайды сипаттамалық салыстыру"))
        PremiumGpsCompareCard(base, verbal, vr, lang)
        ResearchHelpAccordions(lang, HelpSection.HOME)
        ScientificFootnote(lang)
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun ScientificFootnote(lang: String) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp))
        .background(MaterialTheme.colorScheme.primary.copy(alpha = .07f))
        .padding(13.dp), verticalAlignment = Alignment.Top) {
        Icon(Icons.Default.VerifiedUser, null, tint = Mint, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(tr(lang,
            "Исследовательский прототип: не диагноз. Сравнения отражают только немедленные реакции на обратную связь, не эффект лечения. МКФ b770/d450 — справочные категории.",
            "Зерттеу прототипі: диагноз емес. Салыстыру тек кері байланысқа дереу реакцияны көрсетеді, ем әсерін емес. ХКЖ b770/d450 — анықтамалық санаттар."),
            fontSize = 11.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun PremiumPatients(data: GaitDataset, selected: String, search: String, lang: String,
                    onQuery: (String) -> Unit, onPick: (String) -> Unit) {
    val matches = remember(data, search) { data.subjects.filter { it.contains(search, ignoreCase = true) } }
    Column(Modifier.fillMaxSize().padding(horizontal = 17.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(7.dp))
        MiniEyebrow(tr(lang, "Каталог исследования", "Зерттеу тізімі"))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr(lang, "Участники", "Қатысушылар"), fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold, letterSpacing = (-.8).sp)
                Text(tr(lang, "Анонимизированные записи", "Жасырын қатысушы жазбалары"),
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            StatePill("${data.subjects.size} ID", Mint)
        }
        OutlinedTextField(value = search, onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth().then(coachOutline(HelpSection.PARTICIPANTS)), singleLine = true,
            placeholder = { Text(tr(lang, "Поиск по коду участника", "Қатысушы коды бойынша іздеу"), fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, null, tint = Mint) },
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Mint, unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant,
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            MiniEyebrow(tr(lang, "Найдено: ${matches.size}", "Табылды: ${matches.size}"))
            Text(tr(lang, "Открыть анализ →", "Талдауды ашу →"), color = Mint, fontSize = 11.sp)
        }
        val showParticipantCoach = LocalCoach.current.section == HelpSection.PARTICIPANTS
        LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(bottom = 20.dp)) {
            if (showParticipantCoach) item { CoachCallout(lang, HelpSection.PARTICIPANTS) }
            items(matches, key = { it }) { id ->
                val baseline = data.find(id, WalkCondition.BASELINE)
                val verbal = data.find(id, WalkCondition.VERBAL)
                val vr = data.find(id, WalkCondition.VR)
                val delta = GaitAnalytics.delta(baseline?.metric("GPS_a"), vr?.metric("GPS_a"))
                val cycles = listOfNotNull(baseline, verbal, vr).sumOf { it.cycleCount }
                PremiumCard(Modifier.clickable { onPick(id) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp))
                            .background(if (id == selected) Mint.copy(alpha = .15f) else Indigo.copy(alpha = .10f)),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.AccessibilityNew, null,
                                tint = if (id == selected) Mint else Indigo,
                                modifier = Modifier.size(23.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(id, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
                            Text("${baseline?.side ?: verbal?.side ?: vr?.side ?: "—"} · $cycles " +
                                tr(lang, "циклов", "цикл"),
                                fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Icon(if (id == selected) Icons.Default.CheckCircle else Icons.Default.ChevronRight,
                            null, tint = if (id == selected) Mint else MutedInk,
                            modifier = Modifier.size(21.dp))
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .75f))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatePill("Baseline", Indigo)
                        Spacer(Modifier.width(5.dp))
                        StatePill("VR", Mint)
                        Spacer(Modifier.weight(1f))
                        Text("Δ GPS ", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(signed(delta), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                    }
                }
            }
            if (matches.isEmpty()) item {
                PremiumCard {
                    Text(tr(lang, "Ничего не найдено", "Ештеңе табылмады"),
                        fontWeight = FontWeight.Bold)
                    Text(tr(lang, "Попробуйте другой ID", "Басқа ID енгізіңіз"),
                        fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

private fun niceMetric(name: String, lang: String): String = when (name) {
    "GPS_a" -> tr(lang, "Профиль походки GPS", "Жүріс профилі GPS")
    "GVS_aSagP" -> tr(lang, "Отклонение угла таза", "Жамбас бұрышының ауытқуы")
    "GVS_aSagH" -> tr(lang, "Отклонение угла бедра", "Сан бұрышының ауытқуы")
    "GVS_aSagK" -> tr(lang, "Отклонение угла колена", "Тізе бұрышының ауытқуы")
    "GVS_aSagA" -> tr(lang, "Отклонение угла голеностопа", "Тобық бұрышының ауытқуы")
    "aSagP" -> tr(lang, "Сагиттальный угол таза", "Жамбастың сагиттал бұрышы")
    "aSagH" -> tr(lang, "Сагиттальный угол бедра", "Санның сагиттал бұрышы")
    "aSagK" -> tr(lang, "Сагиттальный угол колена", "Тізенің сагиттал бұрышы")
    "aSagA" -> tr(lang, "Сагиттальный угол голеностопа", "Тобықтың сагиттал бұрышы")
    "mSagH" -> tr(lang, "Сагиттальный момент бедра", "Санның сагиттал моменті")
    "aMinSagH" -> tr(lang, "Минимальный угол бедра", "Санның ең кіші бұрышы")
    "pctmZeroStSagH" -> tr(lang, "Смена знака момента", "Момент таңбасының ауысуы")
    else -> name
}

@Composable
private fun ConditionLegend() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(13.dp),
        verticalAlignment = Alignment.CenterVertically) {
        WalkCondition.entries.forEach { c ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(ConditionColorsPremium.getValue(c)))
                Spacer(Modifier.width(5.dp))
                Text(c.fileSuffix, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun PremiumCurve(series: List<Pair<WalkCondition, List<Double?>>>, modifier: Modifier = Modifier,
                 lang: String = "ru",
                 allSeries: List<Pair<WalkCondition, List<Double?>>> = series) {
    val available = allSeries.filter { (_, points) -> points.any { it?.isFinite() == true } }
    val values = series.flatMap { it.second }.filterNotNull().filter { it.isFinite() }
    if (values.isEmpty()) {
        val hidden = available.isNotEmpty()
        Column(modifier.clip(RoundedCornerShape(15.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .55f))
            .padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center) {
            Icon(Icons.Default.ShowChart, null, tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(30.dp))
            Spacer(Modifier.height(8.dp))
            Text(if (hidden) tr(lang, "Кривые с данными скрыты", "Дерегі бар қисықтар жасырылған")
                else tr(lang, "Нет данных для графика", "Графикке деректер жоқ"),
                fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(5.dp))
            Text(if (hidden) tr(lang, "Включите условие с доступными измерениями:",
                    "Өлшемдері бар жағдайды қосыңыз:") + " " + available.joinToString { it.first.fileSuffix }
                else tr(lang, "Для выбранного участника измерения этого показателя отсутствуют в исходных CSV.",
                    "Таңдалған қатысушының бұл көрсеткішінің өлшемдері бастапқы CSV файлдарында жоқ."),
                fontSize = 12.sp, lineHeight = 17.sp, textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (!hidden) {
                Spacer(Modifier.height(5.dp))
                Text(tr(lang, "Отсутствующие значения не заменяются нулями.", "Жоқ мәндер нөлмен алмастырылмайды."),
                    fontSize = 11.sp, textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        return
    }
    val grid = MaterialTheme.colorScheme.outlineVariant
    Canvas(modifier) {
        val loRaw = values.minOrNull() ?: 0.0
        val hiRaw = values.maxOrNull() ?: 1.0
        val range = max(.01, hiRaw - loRaw)
        val bottom = size.height - 10.dp.toPx()
        val top = 11.dp.toPx()
        val left = 7.dp.toPx()
        val right = size.width - 7.dp.toPx()
        val lo = loRaw - range * .12
        val hi = hiRaw + range * .12
        for (i in 0..4) {
            val y = top + (bottom - top) * i / 4f
            drawLine(grid.copy(alpha = .9f), Offset(left, y), Offset(right, y), 1.dp.toPx())
        }
        for (i in 0..4) {
            val x = left + (right - left) * i / 4f
            drawLine(grid.copy(alpha = .6f), Offset(x, top), Offset(x, bottom), .8.dp.toPx())
        }
        series.forEach { (condition, points) ->
            val path = Path()
            var active = false
            points.forEachIndexed { i, value ->
                if (value == null || !value.isFinite()) active = false
                else {
                    val x = left + (right - left) * i / 50f
                    val y = bottom - (bottom - top) * ((value - lo) / (hi - lo)).toFloat()
                    if (active) path.lineTo(x, y) else { path.moveTo(x, y); active = true }
                    // A lone available point must remain visible even when adjacent values are missing.
                    if (points.getOrNull(i - 1)?.isFinite() != true &&
                        points.getOrNull(i + 1)?.isFinite() != true) {
                        drawCircle(ConditionColorsPremium.getValue(condition), 3.dp.toPx(), Offset(x, y))
                    }
                }
            }
            drawPath(path, ConditionColorsPremium.getValue(condition),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
        }
    }
}

@Composable
private fun NumberBox(label: String, value: Double?, delta: Double?, color: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(15.dp)).background(color.copy(alpha = .09f))
        .padding(horizontal = 8.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(label, fontSize = 10.sp, color = color, fontWeight = FontWeight.Bold, maxLines = 1)
        Text(number(value), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold,
            maxLines = 1, letterSpacing = (-.4).sp)
        Text(if (delta == null) "Δ —" else "Δ ${signed(delta)}",
            fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

/** Evidence panel immediately after the waveform: clinical interpretation must remain cautious. */
@Composable
private fun EvidenceComparison(data: GaitDataset, selected: String, lang: String) {
    var groupMode by remember { mutableStateOf(false) }
    var targetCondition by remember { mutableStateOf(WalkCondition.VR) }
    val focusedSubject = if (groupMode) null else selected
    val important = listOf("aMinSagH", "GPS_a", "GVS_aSagP", "GVS_aSagH", "GVS_aSagK", "GVS_aSagA")
    val baseHip = GaitAnalytics.metricMean(data, focusedSubject, WalkCondition.BASELINE, "aMinSagH")
    val targetHip = GaitAnalytics.metricMean(data, focusedSubject, targetCondition, "aMinSagH")
    val baseGps = GaitAnalytics.metricMean(data, focusedSubject, WalkCondition.BASELINE, "GPS_a")
    val targetGps = GaitAnalytics.metricMean(data, focusedSubject, targetCondition, "GPS_a")
    val likelyCompensation = GaitAnalytics.compensationFlag(data, focusedSubject, targetCondition)

    PremiumSection(tr(lang, "Сводка изменений", "Өзгерістер қорытындысы"),
        tr(lang, "Объяснение после графика · сравнение с Baseline", "Графиктен кейінгі түсіндірме · Baseline-пен салыстыру"))
    PremiumCard {
        Text(tr(lang, "Уровень анализа", "Талдау деңгейі"), fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            FilterChip(selected = !groupMode, onClick = { groupMode = false },
                modifier = Modifier.weight(1f),
                label = { Text(tr(lang, "Участник", "Қатысушы"), fontSize = 12.sp) },
                shape = RoundedCornerShape(12.dp))
            FilterChip(selected = groupMode, onClick = { groupMode = true },
                modifier = Modifier.weight(1f),
                label = { Text(tr(lang, "Вся группа (${data.subjects.size})", "Барлық топ (${data.subjects.size})"), fontSize = 12.sp) },
                shape = RoundedCornerShape(12.dp))
        }
        Text(if (groupMode) tr(lang,
            "Среднее рассчитано сначала для каждого участника, затем для группы. При пропусках учитываются только доступные значения. Это не показатели конкретного ребёнка.",
            "Алдымен әр қатысушының орташа мәні, содан кейін топтың орташа мәні есептеледі. Бос мәндер есептелмейді. Бұл бір баланың көрсеткіштері емес.")
        else tr(lang, "Показаны средние измерения выбранного участника по циклам шага.",
            "Таңдалған қатысушының қадам циклдері бойынша орташа мәндері көрсетілген."),
            fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(WalkCondition.VERBAL, WalkCondition.VR).forEach { condition ->
                FilterChip(selected = targetCondition == condition,
                    onClick = { targetCondition = condition }, modifier = Modifier.weight(1f),
                    label = { Text(condition.fileSuffix) },
                    shape = RoundedCornerShape(12.dp))
            }
        }
    }

    PremiumCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.FactCheck, null, tint = Mint, modifier = Modifier.size(21.dp))
            Spacer(Modifier.width(8.dp))
            Text(tr(lang, "Что показывают данные", "Деректер нені көрсетеді"),
                fontSize = 16.sp, fontWeight = FontWeight.ExtraBold)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SummaryPill(lang, "aMinSagH", baseHip, targetHip,
                GaitAnalytics.classify("aMinSagH", baseHip, targetHip), Modifier.weight(1f))
            SummaryPill(lang, "GPS", baseGps, targetGps,
                GaitAnalytics.classify("GPS_a", baseGps, targetGps), Modifier.weight(1f))
        }
        val finding = if (likelyCompensation) tr(lang,
            "Цель по разгибанию бедра улучшилась, но общий GPS вырос. Возможны компенсаторные изменения в других суставах — это гипотеза, а не доказанный механизм. Решение принимает врач.",
            "Санның жазылуы жақсарған, бірақ жалпы GPS өсті. Басқа буындарда компенсациялық өзгерістер болуы мүмкін — бұл дәлелденген себеп емес. Шешімді дәрігер қабылдайды.")
        else tr(lang,
            "Оценивайте целевой угол и общий GPS вместе. Изменение одного параметра не доказывает улучшение походки в целом. Вывод делает врач.",
            "Нысаналы бұрыш пен жалпы GPS-ті бірге бағалаңыз. Бір көрсеткіштің өзгеруі жалпы жүрістің жақсарғанын дәлелдемейді. Қорытындыны дәрігер жасайды.")
        Surface(shape = RoundedCornerShape(15.dp),
            color = if (likelyCompensation) Apricot.copy(alpha = .15f) else Mint.copy(alpha = .10f)) {
            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.Top) {
                Icon(if (likelyCompensation) Icons.Default.WarningAmber else Icons.Default.Info,
                    null, tint = if (likelyCompensation) Apricot else Mint,
                    modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(finding, fontSize = 12.sp, lineHeight = 17.sp,
                    color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }

    PremiumCard {
        Text(tr(lang, "Где изменения", "Өзгерістер қайда"),
            fontSize = 15.sp, fontWeight = FontWeight.ExtraBold)
        important.forEach { metric ->
            val baseline = GaitAnalytics.metricMean(data, focusedSubject, WalkCondition.BASELINE, metric)
            val current = GaitAnalytics.metricMean(data, focusedSubject, targetCondition, metric)
            val kind = GaitAnalytics.classify(metric, baseline, current)
            val statusText = when (kind) {
                GaitAnalytics.Change.CLOSER -> tr(lang, "Меньше отклонение", "Ауытқу азайды")
                GaitAnalytics.Change.FURTHER -> tr(lang, "Больше отклонение", "Ауытқу артты")
                GaitAnalytics.Change.MORE_EXTENSION -> tr(lang, "Больше разгибание", "Жазылу артты")
                GaitAnalytics.Change.LESS_EXTENSION -> tr(lang, "Меньше разгибание", "Жазылу азайды")
                GaitAnalytics.Change.STABLE -> tr(lang, "Без заметной разницы¹", "Айтарлықтай айырма жоқ¹")
                GaitAnalytics.Change.NO_DATA -> tr(lang, "Нет данных", "Дерек жоқ")
                else -> tr(lang, "Изменение без оценки", "Бағаланбаған өзгеріс")
            }
            val tint = when (kind) {
                GaitAnalytics.Change.CLOSER, GaitAnalytics.Change.MORE_EXTENSION -> Mint
                GaitAnalytics.Change.FURTHER, GaitAnalytics.Change.LESS_EXTENSION -> Apricot
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            }
            Row(Modifier.fillMaxWidth().padding(vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(niceMetric(metric, lang), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("${baseline?.format(2) ?: "—"} → ${current?.format(2) ?: "—"}  •  Δ ${GaitAnalytics.delta(baseline, current)?.let { signed(it) } ?: "—"}",
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box(Modifier.clip(RoundedCornerShape(9.dp)).background(tint.copy(alpha = .12f))
                    .padding(horizontal = 8.dp, vertical = 6.dp)) {
                    Text(statusText, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = tint)
                }
            }
        }
        Text(tr(lang,
            "¹ Разница менее 0,005 при округлении до двух знаков. GPS/GVS: ниже = меньше отклонение от эталонной походки. У aMinSagH ниже = больше разгибание бедра, но не обязательно лучше вся походка. Без контрольных диапазонов нельзя утверждать «норма» или «патология». Наблюдения относятся к немедленному эффекту.",
            "¹ Екі таңбаға дейін дөңгелектегенде айырма 0,005-тен аз. GPS/GVS төмен болса, эталон жүрістен ауытқу аз. aMinSagH төмен болса, санның жазылуы артады, бірақ жалпы жүріс міндетті түрде жақсармайды. Бақылау шектері жоқ, сондықтан «норма» не «патология» деуге болмайды. Тек жедел әсер қаралады."),
            fontSize = 10.sp, lineHeight = 15.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SummaryPill(lang: String, label: String, baseline: Double?, current: Double?,
                        change: GaitAnalytics.Change, modifier: Modifier) {
    val positive = change == GaitAnalytics.Change.CLOSER || change == GaitAnalytics.Change.MORE_EXTENSION
    val negative = change == GaitAnalytics.Change.FURTHER || change == GaitAnalytics.Change.LESS_EXTENSION
    val color = when { positive -> Mint; negative -> Apricot; else -> MutedInk }
    Column(modifier.clip(RoundedCornerShape(15.dp)).background(color.copy(alpha = .10f))
        .padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(label, fontSize = 11.sp, color = color, fontWeight = FontWeight.Bold)
        Text("${baseline?.format(2) ?: "—"} → ${current?.format(2) ?: "—"}",
            fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
        Text(when (change) {
            GaitAnalytics.Change.CLOSER -> tr(lang, "Отклонение ↓", "Ауытқу ↓")
            GaitAnalytics.Change.FURTHER -> tr(lang, "Отклонение ↑", "Ауытқу ↑")
            GaitAnalytics.Change.MORE_EXTENSION -> tr(lang, "Разгибание ↑", "Жазылу ↑")
            GaitAnalytics.Change.LESS_EXTENSION -> tr(lang, "Разгибание ↓", "Жазылу ↓")
            GaitAnalytics.Change.STABLE -> tr(lang, "Почти без изменений", "Өзгеріс аз")
            else -> tr(lang, "Нет оценки", "Баға жоқ")
        }, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = color)
    }
}

@Composable
fun PremiumAnalysis(data: GaitDataset, subject: String, curve: String, lang: String,
                    onCurve: (String) -> Unit, onSubject: (String) -> Unit, onReport: () -> Unit) {
    val base = data.find(subject, WalkCondition.BASELINE)
    val verbal = data.find(subject, WalkCondition.VERBAL)
    val vr = data.find(subject, WalkCondition.VR)
    val outliers = listOfNotNull(base, verbal, vr).sumOf { it.metrics["GPS_a"]?.anomalies ?: 0 }
    val missing = listOfNotNull(base, verbal, vr).sumOf { r -> DISCRETE_METRICS.sumOf { r.metrics[it]?.missing ?: 0 } }
    var shownConditions by remember(subject, curve) {
        mutableStateOf(WalkCondition.entries.toSet())
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(17.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)) {
        MiniEyebrow("BIOMECHANICS / RESEARCH")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr(lang, "Анализ походки", "Жүріс талдауы"), fontSize = 27.sp,
                    fontWeight = FontWeight.ExtraBold, letterSpacing = (-.8).sp)
                Text(tr(lang, "Кинематика и дискретные параметры", "Кинематика және дискретті көрсеткіштер"),
                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            FilledTonalIconButton(onClick = onReport,
                colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = Mint.copy(alpha = .14f))) {
                Icon(Icons.Default.PictureAsPdf, tr(lang, "Сохранить PDF", "PDF сақтау"), tint = Mint)
            }
        }
        PremiumCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp))
                    .background(Indigo.copy(alpha = .1f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PersonOutline, null, tint = Indigo)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(subject, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                    Text(tr(lang, "Исследуемая сторона: ", "Зерттеу жағы: ") +
                        (base?.side ?: verbal?.side ?: vr?.side ?: "—"),
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StatePill(tr(lang, "3 условия", "3 жағдай"), Mint)
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                data.subjects.forEach { id ->
                    FilterChip(selected = id == subject, onClick = { onSubject(id) },
                        label = { Text(id.substringAfterLast('_'), fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Mint.copy(alpha = .16f), selectedLabelColor = Mint),
                        shape = RoundedCornerShape(12.dp))
                }
            }
        }
        PremiumSection(tr(lang, "Биомеханические кривые", "Биомеханикалық қисықтар"),
            tr(lang, "Измерения по циклу шага", "Қадам циклінің өлшемдері"))
        Row(Modifier.fillMaxWidth().then(coachOutline(HelpSection.ANALYSIS, 15))
            .horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            WAVE_METRICS.forEach { key ->
                FilterChip(selected = curve == key, onClick = { onCurve(key) },
                    label = { Text(key, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Mint, selectedLabelColor = Color.White),
                    shape = RoundedCornerShape(13.dp))
            }
        }
        CoachCallout(lang, HelpSection.ANALYSIS)
        PremiumCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(niceMetric(curve, lang), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                    Text(tr(lang, "Средние кривые · 51 точка", "Орташа қисықтар · 51 нүкте"),
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StatePill(if (curve == "mSagH") "Nm/kg" else "°", Indigo)
            }
            Spacer(Modifier.height(2.dp))
            val allCurves = listOfNotNull(base, verbal, vr)
                .map { it.condition to it.curves[curve].orEmpty() }
            val visibleCurves = allCurves.filter { it.first in shownConditions }
            PremiumCurve(visibleCurves, Modifier.fillMaxWidth().height(201.dp),
                lang = lang, allSeries = allCurves)
            val noDataConditions = WalkCondition.entries.filter { condition ->
                allCurves.none { (c, points) -> c == condition && points.any { it?.isFinite() == true } }
            }
            if (noDataConditions.isNotEmpty() && noDataConditions.size < WalkCondition.entries.size) {
                Text(tr(lang, "Нет измерений: ", "Өлшемдер жоқ: ") +
                    noDataConditions.joinToString { it.fileSuffix }, fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("0%", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(tr(lang, "ЦИКЛ ШАГА", "ҚАДАМ ЦИКЛІ"), fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = .8.sp)
                Text("100%", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(tr(lang, "Нажмите на условие, чтобы скрыть или показать кривую",
                "Қисықты жасыру не көрсету үшін шартты басыңыз"),
                fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                WalkCondition.entries.forEach { condition ->
                    val active = condition in shownConditions
                    FilterChip(selected = active, onClick = {
                        if (active && shownConditions.size > 1) shownConditions = shownConditions - condition
                        else if (!active) shownConditions = shownConditions + condition
                    }, modifier = Modifier.weight(1f),
                        label = { Text(condition.fileSuffix, maxLines = 1, fontSize = 10.sp) },
                        leadingIcon = {
                            Box(Modifier.size(7.dp).clip(CircleShape)
                                .background(ConditionColorsPremium.getValue(condition)))
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ConditionColorsPremium.getValue(condition).copy(alpha = .14f)),
                        shape = RoundedCornerShape(12.dp))
                }
            }
        }
        // Clinical interpretation is shown immediately after the curve.
        EvidenceComparison(data, subject, lang)
        ResearchHelpAccordions(lang, HelpSection.ANALYSIS)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            DataStat("$outliers", tr(lang, "Нетипич. циклы GPS", "GPS тосын цикл"), Apricot, Modifier.weight(1f))
            DataStat("$missing", tr(lang, "Пропуски значений", "Бос мәндер"), Indigo, Modifier.weight(1f))
        }
        PremiumSection(tr(lang, "Сравнение показателей", "Көрсеткіштерді салыстыру"),
            tr(lang, "Средние по шагам • Δ относительно Baseline", "Қадам бойынша орташа • Δ Baseline-ға қатысты"))
        DISCRETE_METRICS.forEach { metric ->
            val b = base?.metric(metric)
            val v = verbal?.metric(metric)
            val r = vr?.metric(metric)
            PremiumCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(niceMetric(metric, lang), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(metric, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
                    }
                    if (listOf(b, v, r).all { it == null }) StatePill("NaN", Apricot)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    NumberBox("Baseline", b, null, Indigo, Modifier.weight(1f))
                    NumberBox("Verbal", v, GaitAnalytics.delta(b, v), Apricot, Modifier.weight(1f))
                    NumberBox("VR", r, GaitAnalytics.delta(b, r), Mint, Modifier.weight(1f))
                }
            }
        }
        ScientificFootnote(lang)
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun ChatIntro(lang: String, subject: String) {
    val isDark = MaterialTheme.colorScheme.background.red < .2f
    val ink = if (isDark) Color.White else Color(0xFF193D44)
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(23.dp))
        .background(Brush.linearGradient(if (isDark)
            listOf(Color(0xFF113A45), Color(0xFF165258), Color(0xFF107B70))
            else listOf(Color(0xFFE9F9F4), Color(0xFFD4F2ED), Color(0xFFC7E9EF))))) {
        Canvas(Modifier.matchParentSize()) {
            drawCircle(Mint.copy(alpha = if (isDark) .16f else .10f), size.width * .39f,
                Offset(size.width * .98f, size.height * .09f))
            drawCircle(Color.White.copy(alpha = .05f), size.width * .24f,
                Offset(size.width * .96f, size.height * .99f))
        }
        Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(41.dp).clip(RoundedCornerShape(14.dp))
                    .background(Mint.copy(alpha = .15f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.AutoAwesome, null, tint = if (isDark) Cyan else Mint, modifier = Modifier.size(24.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(tr(lang, "AI-помощник врача", "Дәрігерге арналған AI-көмекші"),
                        color = ink, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                    Text(tr(lang, "Объясняет изменения по данным исследования", "Зерттеу деректері бойынша өзгерістерді түсіндіреді"),
                        color = if (isDark) Color(0xFFCCE5E7) else Color(0xFF54737A), fontSize = 11.sp)
                }
                Box(Modifier.size(8.dp).clip(CircleShape).background(
                    if (AiClient.hasTextKey) Cyan else Apricot))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.FolderShared, null, tint = if (isDark) Cyan else Mint, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(5.dp))
                Text(tr(lang, "Контекст: ", "Контекст: ") + subject,
                    fontSize = 11.sp, color = ink, fontWeight = FontWeight.Medium)
                Spacer(Modifier.width(8.dp))
                Text("• CSV", fontSize = 11.sp, color = if (isDark) Color(0xFF9FD3D5) else Mint)
            }
        }
    }
}

@Composable
private fun SuggestedQuestion(text: String, onClick: () -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .75f)),
        modifier = Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, null, tint = Mint, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(9.dp))
            Text(text, modifier = Modifier.weight(1f), fontSize = 12.sp, lineHeight = 17.sp,
                fontWeight = FontWeight.Medium)
            Icon(Icons.Default.NorthEast, null, tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(14.dp))
        }
    }
}

@Composable
private fun VoiceBars(level: Float, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val center = size.height * .5f
        val count = 25
        val barW = size.width / (count * 1.75f)
        for (i in 0 until count) {
            val t = i / (count - 1f)
            val pulse = abs(kotlin.math.sin((i * .66 + 1.0)).toFloat())
            val barH = 4.dp.toPx() + (5.dp.toPx() + size.height * .75f * level) * pulse
            drawLine(Mint.copy(alpha = .38f + pulse * .62f),
                Offset(size.width * t, center - barH / 2),
                Offset(size.width * t, center + barH / 2),
                strokeWidth = barW.coerceAtMost(4.dp.toPx()), cap = StrokeCap.Round)
        }
    }
}

@Composable
fun PremiumAi(lang: String, subject: String, messages: List<Pair<Boolean, String>>,
              input: String, onInput: (String) -> Unit, waiting: Boolean, listening: Boolean,
              processing: Boolean, voiceProvider: String, volume: Float,
              onMic: () -> Unit, onSend: () -> Unit, keyboardVisible: Boolean) {
    val scroll = rememberLazyListState()
    LaunchedEffect(messages.size, waiting, keyboardVisible) {
        if (messages.isNotEmpty()) {
            scroll.animateScrollToItem(messages.size - 1 + (if (waiting) 1 else 0) + (if (keyboardVisible) 0 else 1))
        }
    }
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        // The large intro is removed while typing; the weighted history shrinks,
        // not the composer. Insets are already handled by the root window.
        LazyColumn(
            modifier = Modifier.weight(1f),
            state = scroll,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 12.dp)
        ) {
            if (!keyboardVisible) item { ChatIntro(lang, subject) }
            if (messages.isEmpty()) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(44.dp).clip(RoundedCornerShape(15.dp))
                                .background(Mint.copy(alpha = .12f)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.PsychologyAlt, null, tint = Mint,
                                    modifier = Modifier.size(23.dp))
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(tr(lang, "С чего начнём?", "Неден бастаймыз?"),
                                    fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                                Text(tr(lang, "Задайте вопрос по данным исследования",
                                    "Зерттеу деректері бойынша сұрақ қойыңыз"),
                                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        SuggestedQuestion(tr(lang, "Сравни Baseline, Verbal и VR для участника",
                            "Қатысушы үшін Baseline, Verbal және VR салыстыр")) {
                            onInput(tr(lang, "Сравни Baseline, Verbal и VR по ключевым показателям. Сошлись на числах.",
                                "Baseline, Verbal және VR-ды негізгі көрсеткіштер бойынша салыстыр. Сандарды көрсет."))
                        }
                        SuggestedQuestion(tr(lang, "Какие изменения GPS наиболее заметны?",
                            "GPS бойынша қандай өзгерістер байқалады?")) {
                            onInput(tr(lang, "Объясни изменения GPS относительно Baseline и ограничения этих выводов.",
                                "Baseline-ға қатысты GPS өзгерістерін және қорытынды шектеулерін түсіндір."))
                        }
                        SuggestedQuestion(tr(lang, "Какие параметры имеют пропуски или нетипичные циклы?",
                            "Қандай деректер жоқ немесе қалыптан тыс?")) {
                            onInput(tr(lang, "Перечисли пропуски и нетипичные циклы; не ставь диагноз.",
                                "Жетіспейтін мәндер мен қалыптан тыс циклдарды ата; диагноз қойма."))
                        }
                        PremiumCard {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Security, null, tint = Mint, modifier = Modifier.size(20.dp))
                                Spacer(Modifier.width(7.dp))
                                Text(tr(lang, "Контроль качества выводов", "Қорытынды сапасын бақылау"),
                                    fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Text(tr(lang,
                                "Ассистент получает только рассчитанную сводку выбранного участника. " +
                                "Никаких вымышленных измерений или самостоятельных диагнозов.",
                                "Көмекшіге тек таңдалған қатысушының есептелген қорытындысы жіберіледі. " +
                                "Ойдан шығарылған өлшемдер мен диагноздар жоқ."),
                                fontSize = 11.sp, lineHeight = 16.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (!AiClient.hasTextKey) {
                                Text(tr(lang,
                                    "Ключ OpenRouter не добавлен. Заполните ai.properties и соберите APK повторно.",
                                    "OpenRouter кілті орнатылмаған. ai.properties файлын толтырып APK қайта жинаңыз."),
                                    fontSize = 11.sp, color = Apricot)
                            }
                        }
                    }
                }
            }
            items(messages.size) { i ->
                val (isUser, message) = messages[i]
                Row(Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
                    verticalAlignment = Alignment.Bottom) {
                    if (!isUser) {
                        PremiumLogo(dimension = 28)
                        Spacer(Modifier.width(7.dp))
                    }
                    Surface(modifier = Modifier.fillMaxWidth(if (isUser) .83f else .89f),
                        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp,
                            bottomStart = if (isUser) 20.dp else 5.dp,
                            bottomEnd = if (isUser) 5.dp else 20.dp),
                        color = if (isUser) Mint else MaterialTheme.colorScheme.surface,
                        border = if (isUser) null else BorderStroke(1.dp,
                            MaterialTheme.colorScheme.outlineVariant.copy(alpha = .7f))) {
                        Text(message, modifier = Modifier.padding(15.dp),
                            color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface,
                            fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }
            }
            if (messages.isEmpty()) item {
                ResearchHelpAccordions(lang, HelpSection.AI)
            }
            if (waiting) item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    PremiumLogo(dimension = 28)
                    Spacer(Modifier.width(9.dp))
                    CircularProgressIndicator(color = Mint,
                        modifier = Modifier.size(17.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(tr(lang, "Изучаю сводку...", "Қорытындыны талдаудамын..."),
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        AnimatedVisibility(visible = (listening || processing) && !keyboardVisible) {
            Surface(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp),
                shape = RoundedCornerShape(17.dp), color = Mint.copy(alpha = .09f)) {
                Row(Modifier.padding(horizontal = 13.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (processing) Icons.Default.HourglassTop else Icons.Default.GraphicEq,
                        null, tint = Mint, modifier = Modifier.size(19.dp))
                    Spacer(Modifier.width(7.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (processing) tr(lang, "Распознавание...", "Тану...")
                            else tr(lang, "Слушаю. Нажмите ещё раз, чтобы завершить.",
                                "Тыңдап тұрмын. Аяқтау үшін қайта басыңыз."),
                            fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(voiceProvider, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    VoiceBars(if (processing) .16f else (volume * 10f).coerceIn(.06f, 1f),
                        Modifier.size(width = 66.dp, height = 30.dp))
                }
            }
        }
        if (!keyboardVisible && !listening && !processing) {
            // This callout is anchored above the actual input and never overlays a control.
            CoachCallout(lang, HelpSection.AI, pointsDown = true,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 3.dp))
        }
        Surface(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp)
                .then(coachOutline(HelpSection.AI, 25)),
            shape = RoundedCornerShape(23.dp), color = MaterialTheme.colorScheme.surface,
            shadowElevation = 8.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = .8f))) {
            Row(Modifier.padding(horizontal = 9.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                BasicTextField(value = input, onValueChange = onInput, maxLines = if (keyboardVisible) 3 else 4,
                    modifier = Modifier.weight(1f).heightIn(min = 42.dp, max = if (keyboardVisible) 85.dp else 110.dp)
                        .padding(start = 6.dp, top = 9.dp, bottom = 7.dp),
                    textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 14.sp,
                        lineHeight = 20.sp), cursorBrush = SolidColor(Mint),
                    decorationBox = { field ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (input.isEmpty()) Text(tr(lang, "Спросите об изменениях, циклах или отчёте...", "Өзгерістер, циклдар немесе есеп туралы сұраңыз..."),
                                fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            field()
                        }
                    })
                FilledIconButton(onClick = onMic, enabled = !processing,
                    modifier = Modifier.size(42.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = if (listening) Apricot.copy(alpha = .21f) else Mint.copy(alpha = .11f),
                        contentColor = if (listening) Apricot else Mint)) {
                    Icon(if (listening) Icons.Default.Stop else Icons.Default.Mic,
                        tr(lang, "Голосовой ввод", "Дауыстық енгізу"), modifier = Modifier.size(20.dp))
                }
                FilledIconButton(onClick = onSend, enabled = input.isNotBlank() && !waiting,
                    modifier = Modifier.size(42.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Mint, contentColor = Color.White)) {
                    Icon(Icons.Default.ArrowUpward, tr(lang, "Отправить", "Жіберу"),
                        modifier = Modifier.size(20.dp))
                }
            }
        }
        if (!keyboardVisible) Text(tr(lang, "ИИ — для анализа данных, не для постановки диагноза",
            "ЖИ деректерді талдауға арналған, диагноз қоюға емес"),
            modifier = Modifier.fillMaxWidth().padding(top = 5.dp, bottom = 10.dp),
            textAlign = TextAlign.Center, fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun PremiumSettings(lang: String, dark: Boolean, data: GaitDataset,
                    aiChecking: Boolean, aiCheckMessage: String?, onTestAi: () -> Unit,
                    helpEnabled: Boolean,
                    onHelpEnabled: (Boolean) -> Unit, onReplayGuide: () -> Unit,
                    onLang: (String) -> Unit, onDark: (Boolean) -> Unit,
                    onImport: () -> Unit, onReset: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())
        .padding(17.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        MiniEyebrow(tr(lang, "Персонализация", "Дербестендіру"))
        Text(tr(lang, "Настройки", "Баптаулар"), fontSize = 28.sp,
            fontWeight = FontWeight.ExtraBold, letterSpacing = (-.8).sp)
        PremiumSection(tr(lang, "Интерфейс", "Интерфейс"))
        PremiumCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Language, null, tint = Mint)
                Spacer(Modifier.width(10.dp))
                Text(tr(lang, "Язык приложения", "Қолданба тілі"),
                    modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                FilterChip(selected = lang == "ru", onClick = { onLang("ru") },
                    label = { Text("Русский") },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Mint.copy(alpha = .15f)),
                    shape = RoundedCornerShape(13.dp))
                FilterChip(selected = lang == "kk", onClick = { onLang("kk") },
                    label = { Text("Қазақша") },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Mint.copy(alpha = .15f)),
                    shape = RoundedCornerShape(13.dp))
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DarkMode, null, tint = Mint)
                Spacer(Modifier.width(10.dp))
                Text(tr(lang, "Тёмная тема", "Қараңғы режим"), modifier = Modifier.weight(1f),
                    fontWeight = FontWeight.Bold)
                Switch(checked = dark, onCheckedChange = onDark,
                    colors = SwitchDefaults.colors(checkedTrackColor = Mint))
            }
        }
        PremiumSection(tr(lang, "Обучение и подсказки", "Оқыту және кеңестер"),
            tr(lang, "Небольшие пояснения без затемнения экрана",
                "Экранды қараңғылатпайтын қысқа түсініктемелер"))
        PremiumCard {
            Row(Modifier.fillMaxWidth().then(coachOutline(HelpSection.SETTINGS, 15)), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.TipsAndUpdates, null, tint = Mint)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(tr(lang, "Показывать подсказки", "Кеңестерді көрсету"),
                        fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                    Text(tr(lang, "Автоматические пояснения на новых экранах",
                        "Жаңа беттердегі автоматты түсініктемелер"),
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = helpEnabled, onCheckedChange = onHelpEnabled,
                    colors = SwitchDefaults.colors(checkedTrackColor = Mint))
            }
            CoachCallout(lang, HelpSection.SETTINGS)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Text(tr(lang,
                "Подсказка появляется на нужном экране, не перекрывает кнопки и скрывается по нажатию «Далее». Открыть её снова можно через «?». Запрашивать возраст не требуется.",
                "Кеңес қажетті бетте көрсетіледі, батырмаларды жаппайды және «Келесі» арқылы жабылады. Оны «?» арқылы қайта ашуға болады. Жас сұралмайды."),
                fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onReplayGuide, modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(13.dp)) {
                Icon(Icons.Default.PlayCircleOutline, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(tr(lang, "Снова показать подсказки", "Кеңестерді қайта көрсету"))
            }
        }
        PremiumSection(tr(lang, "Данные исследования", "Зерттеу деректері"))
        PremiumCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Storage, null, tint = Indigo)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(tr(lang, "Импорт CSV", "CSV жүктеу"), fontWeight = FontWeight.Bold)
                    Text("${data.loadedFiles}/6 CSV · ${data.subjects.size} " +
                        tr(lang, "участников", "қатысушы"),
                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StatePill(if (data.complete) tr(lang, "Готово", "Дайын")
                    else tr(lang, "Не полно", "Толық емес"), if (data.complete) Mint else Apricot)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onImport, colors = ButtonDefaults.buttonColors(containerColor = Mint),
                    shape = RoundedCornerShape(13.dp)) {
                    Icon(Icons.Default.Add, null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(tr(lang, "Загрузить", "Жүктеу"), fontSize = 12.sp)
                }
                OutlinedButton(onClick = onReset, enabled = data.loadedFiles > 0,
                    shape = RoundedCornerShape(13.dp)) {
                    Icon(Icons.Default.DeleteOutline, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(tr(lang, "Очистить", "Тазалау"), fontSize = 12.sp)
                }
            }
        }
        PremiumSection(tr(lang, "Подключение к ИИ", "ЖИ қосылымы"))
        PremiumCard {
            FeatureRow(Icons.Default.AutoAwesome, "OpenRouter",
                if (AiClient.hasTextKey) tr(lang, "Ключ включён в APK", "Кілт APK ішінде")
                else tr(lang, "Ключ отсутствует", "Кілт жоқ"),
                if (AiClient.hasTextKey) Mint else Apricot)
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            FeatureRow(Icons.Default.Mic, "gpt-live-transcribe",
                if (AiClient.hasVoiceKey) tr(lang, "Ключ OpenAI задан", "OpenAI кілті бар")
                else tr(lang, "Резервное распознавание Android", "Android резервтік тануы"),
                Indigo)
            Button(onClick = onTestAi, enabled = !aiChecking && AiClient.hasTextKey,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Mint)) {
                if (aiChecking) CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp,
                    modifier = Modifier.size(16.dp))
                else Icon(Icons.Default.NetworkCheck, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (aiChecking) tr(lang, "Проверяем...", "Тексерілуде...")
                    else tr(lang, "Проверить подключение к ИИ", "ЖИ қосылымын тексеру"))
            }
            if (aiCheckMessage != null) Text(aiCheckMessage, fontSize = 11.sp,
                lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurface)

        }
        PremiumSection(tr(lang, "О методике и безопасности", "Әдістеме және қауіпсіздік туралы"))
        ResearchHelpAccordions(lang, HelpSection.SETTINGS)
        DocumentationSection(lang)
        ScientificFootnote(lang)
        Text("VostokLab", fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        Spacer(Modifier.height(5.dp))
    }
}


/** Offline documentation. Uses the same expandable cards as the existing settings. */
@Composable
private fun DocumentationSection(lang: String) {
    PremiumSection(tr(lang, "Документация", "Құжаттама"),
        tr(lang, "Руководство, методика и источники", "Нұсқаулық, әдістеме және дереккөздер"))
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        DetailAccordion(lang, "О приложении", "Қолданба туралы",
            "VostokLab — исследовательский помощник врача для сравнения походки детей с ДЦП при обычной ходьбе (Baseline), вербальной (Verbal) и VR-обратной связи. Разработан для школьного трека AI-Sana Shakarim Solveathon 2026.",
            "VostokLab — БЦС бар балалардың әдеттегі жүрісін (Baseline), ауызша (Verbal) және VR кері байланыс жағдайларын салыстыруға арналған дәрігердің зерттеу көмекшісі. AI-Sana Shakarim Solveathon 2026 мектеп трегіне арналған.")
        DetailAccordion(lang, "Руководство пользователя", "Пайдаланушы нұсқаулығы",
            "1. На главной выберите исходный ZIP или шесть CSV.\n2. Откройте список участников и выберите ID.\n3. В анализе выберите показатель, условия и уровень сравнения: участник или группа.\n4. Изучите сводку, задайте вопрос ИИ при необходимости.\n5. Сохраните PDF кнопкой отчёта. Язык, тему и подсказки можно изменить в настройках.",
            "1. Басты бетте ZIP немесе алты CSV файлын таңдаңыз.\n2. Қатысушылар тізімінен ID таңдаңыз.\n3. Талдауда көрсеткішті, жағдайларды және салыстыру деңгейін таңдаңыз: қатысушы немесе топ.\n4. Қорытындыны қарап, қажет болса ЖИ-ға сұрақ қойыңыз.\n5. Есеп батырмасымен PDF сақтаңыз. Тілді, тақырыпты және кеңестерді баптауларда өзгертуге болады.")
        DetailAccordion(lang, "Методика и формулы", "Әдістеме және формулалар",
            "CSV: разделитель ;, десятичная запятая, одна строка — цикл шага. Среднее = сумма доступных значений / их количество. Среднее группы = среднее из средних участников (равные веса). Δ = значение условия − Baseline. Кривые: 51 точка от 0 до 100% цикла с шагом 2%. Пропуски NaN исключаются из расчёта; при отсутствии измерений результат не определяется. Нетипичные циклы GPS отмечаются по модифицированному Z-показателю 0,6745 × |x − медиана| / MAD > 3,5 (при ненулевом MAD). MAD — медиана абсолютных отклонений от медианы; это не диагноз.",
            "CSV: бөлгіш ;, ондық үтір, бір жол — бір қадам циклі. Орташа = қолжетімді мәндер қосындысы / саны. Топтық орташа = қатысушылар орташаларының орташа мәні (салмақтары тең). Δ = жағдай мәні − Baseline. Қисықта 0–100% аралығында 2% қадаммен 51 нүкте бар. NaN есептелмейді; өлшемдер болмаса нәтиже анықталмайды. GPS-тің қалыптан тыс циклдері 0,6745 × |x − медиана| / MAD > 3,5 модификацияланған Z көрсеткішімен белгіленеді (MAD нөлден өзгеше болғанда). MAD — медианадан абсолют ауытқулардың медианасы; бұл диагноз емес.")
        DetailAccordion(lang, "GPS, GVS и клиническая сводка", "GPS, GVS және клиникалық қорытынды",
            "GPS отражает общее отклонение походки от эталонных кривых, GVS — отклонение отдельной кинематической составляющей. Эти индексы взяты из CSV, приложение агрегирует их, а не рассчитывает заново по эталонным кривым. aMinSagH — минимальный сагиттальный угол бедра. Увеличение разгибания при росте GPS может указывать на компенсацию, но не доказывает её. Изменения описательные, не оценка клинической значимости. Решение принимает врач.",
            "GPS жүрістің эталондық қисықтардан жалпы ауытқуын, GVS жеке кинематикалық құрамдастың ауытқуын көрсетеді. Индекстер CSV-ден алынады, қолданба оларды жинақтайды, эталондық қисықтардан қайта есептемейді. aMinSagH — санның ең кіші сагиттал бұрышы. Санның жазылуы артып, GPS өскенде компенсация болуы мүмкін, бірақ бұл дәлел емес. Өзгерістер сипаттамалық, клиникалық маңыздылық бағасы емес. Шешімді дәрігер қабылдайды.")
        DetailAccordion(lang, "Искусственный интеллект", "Жасанды интеллект",
            "Числа и графики вычисляются локальным алгоритмом Kotlin. Текстовый ассистент отправляет вопрос, обезличенный ID, агрегаты выбранного участника и групповые сравнения в OpenRouter через HTTPS. Модель: " + BuildConfig.OPENROUTER_MODEL + ". Ответы нужно сверять с данными. Голос: OpenAI gpt-live-transcribe при наличии отдельного ключа или системное распознавание Android. ChatGPT использовался при разработке. Прототип не содержит клинически валидированной обученной ML-модели.",
            "Сандар мен графиктер жергілікті Kotlin алгоритмімен есептеледі. Мәтіндік көмекші сұрақты, жасырын ID-ді, қатысушының жинақталған деректерін және топтық салыстыруды HTTPS арқылы OpenRouter-ге жібереді. Модель: " + BuildConfig.OPENROUTER_MODEL + ". Жауаптарды деректермен тексеру керек. Дауыс: бөлек кілт болса OpenAI gpt-live-transcribe, болмаса Android жүйелік тануы. Әзірлеуде ChatGPT қолданылды. Прототипте клиникалық тексерілген оқытылған ML моделі жоқ.")
        DetailAccordion(lang, "Источники данных", "Дереккөздер",
            "De Mulder T., Adams H., Dewit T., Molenaers G., Van Campenhout A., Desloovere K. (2024). A Comparison of the Immediate Effects of Verbal and Virtual Reality Feedback on Gait in Children with Cerebral Palsy. KU Leuven Research Data Repository, V1. DOI: 10.48804/JUNNWW. Лицензия CC BY-NC-SA 4.0 (указание авторства, некоммерческое использование, сохранение лицензии при распространении адаптированных данных). Публикация: DOI 10.3390/children11050524. Исходные файлы предоставлены для конкурсного кейса.",
            "De Mulder T., Adams H., Dewit T., Molenaers G., Van Campenhout A., Desloovere K. (2024). A Comparison of the Immediate Effects of Verbal and Virtual Reality Feedback on Gait in Children with Cerebral Palsy. KU Leuven Research Data Repository, V1. DOI: 10.48804/JUNNWW. CC BY-NC-SA 4.0 лицензиясы (авторды көрсету, коммерциялық емес пайдалану, бейімделген деректерді таратқанда лицензияны сақтау). Мақала: DOI 10.3390/children11050524. Бастапқы файлдар байқау тапсырмасына берілген.")
        DetailAccordion(lang, "Безопасность и ограничения", "Қауіпсіздік және шектеулер",
            "Используйте только открытые, синтетические или полностью обезличенные данные. Не вводите персональные сведения в чат или голосовой ввод. CSV и PDF обрабатываются на устройстве; текстовый и голосовой ИИ могут передавать сведения внешним сервисам. Для публичного внедрения необходима защищённая архитектура доступа к API. Прототип не ставит диагнозы, не назначает лечение и не доказывает долгосрочный эффект. При угрозе здоровью обратитесь к врачу; при неотложной ситуации в Казахстане звоните 103. Интернет нужен для онлайн-ИИ; локальный анализ работает без него.",
            "Тек ашық, синтетикалық немесе толық иесіздендірілген деректерді пайдаланыңыз. Чатқа немесе дауыстық енгізуге жеке мәліметтерді енгізбеңіз. CSV және PDF құрылғыда өңделеді; мәтіндік және дауыстық ЖИ мәліметтерді сыртқы қызметтерге жіберуі мүмкін. Жария енгізу үшін API-ге қорғалған қолжетімділік архитектурасы қажет. Прототип диагноз қоймайды, ем тағайындамайды және ұзақ мерзімді әсерді дәлелдемейді. Денсаулыққа қауіп төнсе дәрігерге жүгініңіз; Қазақстанда шұғыл жағдайда 103 нөміріне қоңырау шалыңыз. Онлайн ЖИ-ға интернет қажет, жергілікті талдау онсыз жұмыс істейді.")
        DetailAccordion(lang, "Технологии и лицензии", "Технологиялар мен лицензиялар",
            "Kotlin, Jetpack Compose / AndroidX, kotlinx.coroutines и OkHttp — Apache License 2.0. Android SDK и PdfDocument — платформенные компоненты Android. OpenRouter и OpenAI API — по условиям соответствующих сервисов. Полный перечень инструментов и лицензий: AI_TOOLS_AND_SOURCES.md в исходном проекте.\nСправка: apache.org/licenses/LICENSE-2.0; creativecommons.org/licenses/by-nc-sa/4.0/.",
            "Kotlin, Jetpack Compose / AndroidX, kotlinx.coroutines және OkHttp — Apache License 2.0. Android SDK және PdfDocument — Android платформасының құрамдастары. OpenRouter және OpenAI API — тиісті қызметтердің шарттары бойынша. Құралдар мен лицензиялардың толық тізімі бастапқы жобадағы AI_TOOLS_AND_SOURCES.md файлында.\nАнықтама: apache.org/licenses/LICENSE-2.0; creativecommons.org/licenses/by-nc-sa/4.0/.")
        DetailAccordion(lang, "Перспективы развития", "Даму перспективалары",
            "Следующие этапы: адаптация к другим форматам походки, сравнение повторных исследований, планшетная и веб-версии, защищённая интеграция с медицинскими системами. Перед клиническим внедрением нужны проверка врачами, валидация на независимых данных и согласование лицензий. Это план, а не уже реализованные функции.",
            "Келесі кезеңдер: жүріс деректерінің басқа форматтарына бейімдеу, қайталама зерттеулерді салыстыру, планшеттік және веб-нұсқалар, медициналық жүйелермен қорғалған интеграция. Клиникаға енгізер алдында дәрігерлердің тексеруі, тәуелсіз деректерде валидация және лицензияларды келісу қажет. Бұл жоспар, іске асырылған функциялар емес.")
    }
}
