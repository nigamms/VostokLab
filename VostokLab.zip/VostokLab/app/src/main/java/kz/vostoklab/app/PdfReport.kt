package kz.vostoklab.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import java.io.IOException
import kotlin.math.max

/** Saves a deterministic, offline study report with a real 51-point gait-cycle plot.
 * The input consists only of imported CSVs; no diagnosis or inferred clinical outcomes.
 */
object PdfReport {
    fun save(context: Context, uri: Uri, data: GaitDataset, subject: String, lang: String) {
        val doc = PdfDocument()
        try {
            val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
            val c = page.canvas
            val kz = lang == "kk"
            val ink = Color.rgb(11, 29, 47)
            val muted = Color.rgb(80, 104, 117)
            val teal = Color.rgb(13, 182, 168)
            val base = data.find(subject, WalkCondition.BASELINE)
            val verbal = data.find(subject, WalkCondition.VERBAL)
            val vr = data.find(subject, WalkCondition.VR)
            fun box(left: Float, top: Float, right: Float, bottom: Float, color: Int, radius: Float = 14f) {
                c.drawRoundRect(RectF(left, top, right, bottom), radius, radius,
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color })
            }
            fun text(value: String, x: Float, y: Float, size: Float = 11f,
                     color: Int = ink, bold: Boolean = false) {
                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    this.color = color
                    textSize = size
                    typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD)
                        else Typeface.create("sans-serif", Typeface.NORMAL)
                }
                c.drawText(value, x, y, paint)
            }
            box(0f, 0f, 595f, 106f, ink, 0f)
            text("VOSTOKLAB", 32f, 46f, 25f, Color.WHITE, true)
            text(if (kz) "Жүріс деректерін талдау есебі" else "Отчёт об анализе походки", 33f, 72f, 12f,
                Color.rgb(185, 247, 239))
            text("AI & Medicine 2026", 428f, 43f, 10f, Color.WHITE)
            box(30f, 122f, 565f, 197f, Color.rgb(233, 250, 248))
            text(if (kz) "ҚАТЫСУШЫ" else "УЧАСТНИК", 45f, 144f, 10f, teal, true)
            text(subject, 45f, 172f, 20f, ink, true)
            text(if (kz) "Жақ: ${base?.side ?: "—"}" else "Сторона: ${base?.side ?: "—"}", 315f, 151f, 11f)
            text(if (kz) "Циклдер: ${listOfNotNull(base, verbal, vr).sumOf { it.cycleCount }}" else
                "Циклов: ${listOfNotNull(base, verbal, vr).sumOf { it.cycleCount }}", 315f, 175f, 11f)
            text(if (kz) "GPS (орташа)" else "GPS (среднее)", 33f, 227f, 13f, ink, true)
            val columns = listOf("BASELINE" to base, "VERBAL" to verbal, "VR" to vr)
            columns.forEachIndexed { i, pair ->
                val x = 30f + i * 182f
                box(x, 239f, x + 171f, 299f, Color.rgb(244, 248, 251))
                text(pair.first, x + 12f, 258f, 9f, muted, true)
                text(pair.second?.metric("GPS_a")?.format(2) ?: "—", x + 12f, 286f, 19f, teal, true)
            }
            text(if (kz) "Жамбас буынының сагиттал бұрышы · 0–100%" else
                "Сагиттальный угол бедра · 0–100% цикла", 33f, 330f, 12f, ink, true)
            drawCurve(c, listOfNotNull(base, verbal, vr), "aSagH", 45f, 348f, 505f, 160f)
            val colorMap = mapOf(WalkCondition.BASELINE to Color.rgb(105, 126, 237),
                WalkCondition.VERBAL to Color.rgb(245, 167, 105), WalkCondition.VR to teal)
            var legendX = 39f
            WalkCondition.entries.forEach { condition ->
                box(legendX, 519f, legendX + 10f, 529f, colorMap.getValue(condition), 3f)
                text(condition.fileSuffix, legendX + 16f, 528f, 10f, muted)
                legendX += 120f
            }
            text(if (kz) "Дискретті көрсеткіштер (орташа)" else "Дискретные параметры (средние)",
                33f, 559f, 12f, ink, true)
            val metricTitles = mapOf(
                "GPS_a" to "GPS", "GVS_aSagP" to "GVS pelvis", "GVS_aSagH" to "GVS hip",
                "GVS_aSagK" to "GVS knee", "GVS_aSagA" to "GVS ankle",
                "aMinSagH" to "Min hip angle", "pctmZeroStSagH" to "Zero stance moment (%)")
            box(30f, 569f, 565f, 589f, ink, 3f)
            text(if (kz) "Көрсеткіш" else "Показатель", 40f, 583f, 10f, Color.WHITE, true)
            text("Baseline", 288f, 583f, 10f, Color.WHITE)
            text("Verbal", 384f, 583f, 10f, Color.WHITE)
            text("VR", 483f, 583f, 10f, Color.WHITE)
            DISCRETE_METRICS.forEachIndexed { i, metric ->
                val y = 609f + i * 21f
                if (i % 2 == 0) box(30f, y - 16f, 565f, y + 5f, Color.rgb(246, 249, 250), 2f)
                text(metricTitles[metric] ?: metric, 40f, y, 9.5f, ink)
                text(base?.metric(metric)?.format(2) ?: "—", 288f, y, 10f)
                text(verbal?.metric(metric)?.format(2) ?: "—", 384f, y, 10f)
                text(vr?.metric(metric)?.format(2) ?: "—", 483f, y, 10f)
            }
            text(if (kz) "ICF: b770 (жүріс үлгісі), d450 (жүру) — тек анықтама" else
                "МКФ: b770 (функции паттерна походки), d450 (ходьба) — справочно",
                33f, 758f, 9f, muted)
            text(if (kz) "GPS ауытқу белгілері (MAD Z>3.5): " else "Нетипичные GPS-циклы (MAD Z>3.5): ",
                33f, 778f, 9f, muted)
            val flagged = listOfNotNull(base, verbal, vr).sumOf { it.metrics["GPS_a"]?.anomalies ?: 0 }
            text(flagged.toString(), 317f, 778f, 9f, teal, true)
            c.drawLine(33f, 792f, 562f, 792f, Paint().apply { color = Color.LTGRAY })
            text(if (kz) "Зерттеу прототипі · диагноз немесе ем тағайындау емес" else
                "Исследовательский прототип · не диагноз и не назначение лечения", 33f, 807f, 8.5f, muted)
            text("KU Leuven RDR · 10.48804/JUNNWW", 33f, 823f, 8.5f, muted)
            doc.finishPage(page)
            addEvidencePage(doc, data, subject, lang)
            context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
                ?: throw IOException("Cannot open PDF destination")
        } finally { doc.close() }
    }

    /** A second page explains the measurement trade-off without declaring a diagnosis. */
    private fun addEvidencePage(doc: PdfDocument, data: GaitDataset, subject: String, lang: String) {
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 2).create())
        val canvas = page.canvas
        val kz = lang == "kk"
        val ink = Color.rgb(20, 44, 57)
        val muted = Color.rgb(91, 111, 123)
        val teal = Color.rgb(11, 145, 131)
        val amber = Color.rgb(164, 105, 28)
        fun text(s: String, x: Float, y: Float, size: Float, color: Int = ink, bold: Boolean = false) {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                this.color = color
                textSize = size
                typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
            }
            canvas.drawText(s, x, y, paint)
        }
        fun wrap(value: String, x: Float, startY: Float, width: Float, size: Float,
                 color: Int = ink, line: Float = size * 1.45f, bold: Boolean = false): Float {
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = size
                typeface = Typeface.create("sans-serif", if (bold) Typeface.BOLD else Typeface.NORMAL)
            }
            var current = ""
            var y = startY
            for (word in value.split(' ')) {
                val candidate = if (current.isEmpty()) word else "$current $word"
                if (paint.measureText(candidate) > width && current.isNotEmpty()) {
                    text(current, x, y, size, color, bold)
                    y += line
                    current = word
                } else current = candidate
            }
            if (current.isNotBlank()) { text(current, x, y, size, color, bold); y += line }
            return y
        }
        canvas.drawColor(Color.WHITE)
        canvas.drawRect(0f, 0f, 595f, 95f, Paint().apply { color = ink })
        text(if (kz) "ЖҮРІС ӨЗГЕРІСТЕРІНІҢ ҚОРЫТЫНДЫСЫ" else "СВОДКА ИЗМЕНЕНИЙ ПОХОДКИ",
            32f, 43f, 18f, Color.WHITE, true)
        text("VostokLab  /  $subject", 32f, 69f, 11f, Color.rgb(198, 241, 236))
        var y = 118f
        y = wrap(if (kz) "Салыстыру: Baseline және VR. Тек қатысушының циклдер бойынша орташа мәндері."
            else "Сравнение Baseline и VR. Средние по циклам только выбранного участника.",
            32f, y, 520f, 11f, muted)
        y += 15f
        text(if (kz) "Көрсеткіш" else "Показатель", 32f, y, 11f, ink, true)
        text("Baseline", 280f, y, 11f, ink, true)
        text("VR", 365f, y, 11f, ink, true)
        text(if (kz) "Өзгеріс" else "Трактовка", 430f, y, 11f, ink, true)
        y += 13f
        canvas.drawLine(32f, y, 563f, y, Paint().apply { color = Color.LTGRAY })
        y += 21f
        val metrics = listOf(
            "aMinSagH" to (if (kz) "Санның жазылуы" else "Разгибание бедра"),
            "GPS_a" to "GPS",
            "GVS_aSagP" to (if (kz) "Таз ауытқуы" else "Отклонение таза"),
            "GVS_aSagH" to (if (kz) "Сан ауытқуы" else "Отклонение бедра"),
            "GVS_aSagK" to (if (kz) "Тізе ауытқуы" else "Отклонение колена"),
            "GVS_aSagA" to (if (kz) "Тобық ауытқуы" else "Отклонение голеностопа")
        )
        metrics.forEach { (metric, title) ->
            val b = GaitAnalytics.metricMean(data, subject, WalkCondition.BASELINE, metric)
            val v = GaitAnalytics.metricMean(data, subject, WalkCondition.VR, metric)
            val kind = GaitAnalytics.classify(metric, b, v)
            val label = when (kind) {
                GaitAnalytics.Change.CLOSER -> if (kz) "Аз ауытқу" else "Меньше откл."
                GaitAnalytics.Change.FURTHER -> if (kz) "Көп ауытқу" else "Больше откл."
                GaitAnalytics.Change.MORE_EXTENSION -> if (kz) "Жазылу артты" else "Больше разг."
                GaitAnalytics.Change.LESS_EXTENSION -> if (kz) "Жазылу азайды" else "Меньше разг."
                GaitAnalytics.Change.STABLE -> if (kz) "Өзгеріс аз" else "Почти без изм."
                else -> if (kz) "Дерек жоқ" else "Нет данных"
            }
            val highlight = kind == GaitAnalytics.Change.FURTHER || kind == GaitAnalytics.Change.LESS_EXTENSION
            text(title, 32f, y, 10f)
            text(b?.format(2) ?: "—", 280f, y, 10f)
            text(v?.format(2) ?: "—", 365f, y, 10f)
            text(label, 430f, y, 9.5f, if (highlight) amber else teal, true)
            y += 30f
        }
        y += 19f
        text(if (kz) "Негізгі қорытынды" else "Ключевой вывод", 32f, y, 15f, ink, true)
        y += 24f
        val contrast = GaitAnalytics.compensationFlag(data, subject, WalkCondition.VR)
        val finding = if (contrast) {
            if (kz) "Санның жазылуы артты, бірақ GPS өсті. Басқа буындарда компенсациялық өзгерістер болуы мүмкін. Бұл дәлелденген механизм емес. Шешімді дәрігер қабылдайды."
            else "Разгибание бедра увеличилось, но общий GPS вырос. Возможны компенсаторные изменения в других суставах, однако их механизм не доказан. Решение принимает врач."
        } else {
            if (kz) "Мақсатты бұрыш пен GPS өзгерістерін бірге қарау керек. Бір көрсеткіштің өзгеруі бүкіл жүрістің жақсарғанын дәлелдемейді. Шешімді дәрігер қабылдайды."
            else "Целевой угол и общий GPS необходимо оценивать вместе. Изменение одного показателя не доказывает улучшение всей походки. Решение принимает врач."
        }
        y = wrap(finding, 32f, y, 523f, 11f, ink, 17f)
        y += 25f
        y = wrap(if (kz) "Шектеу: бұл тек дереу реакция. GPS/GVS төмендеуі эталондық үлгіден аз ауытқуды білдіреді; ол диагноз да, толық норма да емес."
        else "Ограничение: это только немедленная реакция. Снижение GPS/GVS означает меньшее отклонение от референса, но не подтверждает норму или эффективность лечения.",
        32f, y, 523f, 10f, muted, 15f)
        y += 13f
        text("KU Leuven RDR · 10.48804/JUNNWW", 32f, 807f, 9.5f, muted)
        doc.finishPage(page)
    }

    private fun drawCurve(c: Canvas, records: List<GaitRecord>, metric: String,
                          left: Float, top: Float, width: Float, height: Float) {
        val all = records.flatMap { it.curves[metric].orEmpty() }.filterNotNull()
        if (all.isEmpty()) return
        val low = all.minOrNull() ?: return
        val high = all.maxOrNull() ?: return
        val range = max(1.0, high - low)
        val bottom = top + height
        val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(219, 231, 234); strokeWidth = 1f }
        for (i in 0..4) {
            val y = top + height * i / 4
            c.drawLine(left, y, left + width, y, grid)
        }
        for (i in 0..5) {
            val x = left + width * i / 5
            c.drawLine(x, top, x, bottom, grid)
        }
        val colors = mapOf(WalkCondition.BASELINE to Color.rgb(105, 126, 237),
            WalkCondition.VERBAL to Color.rgb(245, 167, 105), WalkCondition.VR to Color.rgb(13, 182, 168))
        records.forEach { record ->
            val points = record.curves[metric].orEmpty()
            val path = Path()
            var prevValid = false
            points.forEachIndexed { i, value ->
                if (value == null) { prevValid = false; return@forEachIndexed }
                val x = left + i * width / 50f
                val y = (bottom - height * ((value - low + range * .08) / (range * 1.16))).toFloat()
                if (!prevValid) path.moveTo(x, y) else path.lineTo(x, y)
                prevValid = true
            }
            c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = colors.getValue(record.condition)
                strokeWidth = 2.4f
                style = Paint.Style.STROKE
            })
        }
    }
}
