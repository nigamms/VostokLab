package kz.vostoklab.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

/** The application intentionally ships with NO study CSVs. All six are imported by the doctor. */
class GaitRepository(private val context: Context) {
    private val csvDir = File(context.filesDir, "imported_csv").apply { mkdirs() }
    private val names = CsvKind.entries.flatMap { k ->
        WalkCondition.entries.map { c -> "${k.prefix}${c.fileSuffix}.csv" }
    }

    fun expectedNames(): List<String> = names.toList()

    suspend fun presentNames(): List<String> = withContext(Dispatchers.IO) {
        names.filter { File(csvDir, it).isFile }
    }

    suspend fun load(): GaitDataset = withContext(Dispatchers.IO) {
        val parser = GaitParser()
        names.forEach { name ->
            val file = File(csvDir, name)
            if (file.isFile) file.reader(Charsets.UTF_8).use { parser.addCsv(name, it) }
        }
        parser.build()
    }

    /** Accept 1-6 CSVs and/or a ZIP containing the original six named CSVs.
     * Stage + validate the entire selection before replacing existing data. */
    suspend fun importFiles(uris: List<Uri>): List<String> = withContext(Dispatchers.IO) {
        require(uris.isNotEmpty()) { "No files selected" }
        val stage = File(context.cacheDir, "csv_import_${System.nanoTime()}").apply { mkdirs() }
        val incoming = linkedMapOf<String, File>()
        var totalSize = 0L
        fun canonical(name: String): String = names.firstOrNull { it.equals(name.substringAfterLast('/').substringAfterLast('\\'), true) }
            ?: throw IllegalArgumentException("Неизвестный CSV: $name")
        fun collect(name: String, stream: InputStream) {
            val finalName = canonical(name)
            require(finalName !in incoming) { "Дублирующийся файл: $finalName" }
            val file = File(stage, finalName)
            file.outputStream().use { out ->
                val buf = ByteArray(8192)
                var local = 0L
                while (true) {
                    val n = stream.read(buf)
                    if (n < 0) break
                    local += n
                    totalSize += n
                    require(local <= 12_000_000 && totalSize <= 48_000_000) { "Файлы слишком большие" }
                    out.write(buf, 0, n)
                }
            }
            // A filename match is not enough: validate both headings and all rows.
            GaitParser().also { parser -> file.reader(Charsets.UTF_8).use { parser.addCsv(finalName, it) } }
            incoming[finalName] = file
        }
        try {
            uris.forEach { uri ->
                val displayName = context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
                } ?: uri.lastPathSegment?.substringAfterLast('/') ?: error("Имя файла не найдено")
                if (displayName.endsWith(".zip", true)) {
                    context.contentResolver.openInputStream(uri)?.use { raw ->
                        ZipInputStream(raw).use { zip ->
                            var entries = 0
                            while (true) {
                                val entry = zip.nextEntry ?: break
                                if (!entry.isDirectory && entry.name.endsWith(".csv", true)) {
                                    entries++
                                    require(entries <= 12) { "Слишком много CSV в ZIP" }
                                    collect(entry.name, zip)
                                }
                                zip.closeEntry()
                            }
                        }
                    } ?: error("Невозможно открыть ZIP")
                } else {
                    context.contentResolver.openInputStream(uri)?.use { collect(displayName, it) }
                        ?: error("Невозможно открыть $displayName")
                }
            }
            require(incoming.isNotEmpty()) { "В выбранных файлах нет подходящих CSV" }
            // Validate combined files before touching active copies.
            val combined = GaitParser()
            names.forEach { name ->
                val candidate = incoming[name] ?: File(csvDir, name).takeIf { it.isFile }
                candidate?.reader(Charsets.UTF_8)?.use { combined.addCsv(name, it) }
            }
            combined.build()
            // Commit after all input files passed validation.
            incoming.forEach { (name, src) -> src.copyTo(File(csvDir, name), overwrite = true) }
            incoming.keys.toList()
        } finally {
            stage.deleteRecursively()
        }
    }

    suspend fun reset() = withContext(Dispatchers.IO) {
        names.forEach { File(csvDir, it).delete() }
    }
}
