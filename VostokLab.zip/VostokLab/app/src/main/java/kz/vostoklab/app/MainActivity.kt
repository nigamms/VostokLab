package kz.vostoklab.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import android.app.Activity
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

private val Marine = Color(0xFF092233)
private val Teal = Color(0xFF009F9C)
private val Blue = Color(0xFF5389F2)
private val Orange = Color(0xFFFFA655)
private val Pale = Color(0xFFF4F7FA)
private val Ink = Color(0xFF132A3C)
private val ChartColors = mapOf(WalkCondition.BASELINE to Blue,
    WalkCondition.VERBAL to Orange, WalkCondition.VR to Teal)

private fun l(lang: String, ru: String, kk: String) = if (lang == "kk") kk else ru

class MainActivity : ComponentActivity() {
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // One edge-to-edge inset owner. adjustResize is retained in the manifest.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        setContent { VostokLabApp() }
    }
}

@Composable
private fun VostokLabApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("vostoklab_settings", 0) }
    val repository = remember { GaitRepository(context) }
    val scope = rememberCoroutineScope()
    val ui = remember { Handler(Looper.getMainLooper()) }
    var lang by remember { mutableStateOf(prefs.getString("lang", "ru") ?: "ru") }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", false)) }
    var tab by remember { mutableIntStateOf(0) }
    var showImportRequired by remember { mutableStateOf(false) }
    // Non-modal coach marks; no age collection and no interaction lock.
    var helpEnabled by remember { mutableStateOf(prefs.getBoolean("inline_help_enabled", true)) }
    var forceHelpFor by remember { mutableStateOf<HelpSection?>(null) }
    var seenHelp by remember {
        mutableStateOf(HelpSection.entries.filter {
            prefs.getBoolean("inline_seen_${it.name}", false)
        }.toSet())
    }
    var dataset by remember { mutableStateOf<GaitDataset?>(null) }
    var selected by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var importMessage by remember { mutableStateOf("") }
    var curveName by remember { mutableStateOf("aSagH") }
    var query by remember { mutableStateOf("") }
    var chatInput by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<Pair<Boolean, String>>() }
    var waiting by remember { mutableStateOf(false) }
    var aiChecking by remember { mutableStateOf(false) }
    var aiCheckMessage by remember { mutableStateOf<String?>(null) }
    var aiRequestId by remember { mutableIntStateOf(0) }
    var listening by remember { mutableStateOf(false) }
    var audioLevel by remember { mutableFloatStateOf(0f) }
    var transcriptionBase by remember { mutableStateOf("") }
    var transcriber by remember { mutableStateOf<VoiceSession?>(null) }
    var voiceProcessing by remember { mutableStateOf(false) }
    var voiceProvider by remember { mutableStateOf("") }
    val loadData: () -> Unit = {
        scope.launch {
            loading = true; error = null
            try {
                dataset = repository.load()
                if (selected.isBlank() || selected !in (dataset?.subjects ?: emptyList()))
                    selected = dataset?.subjects?.firstOrNull().orEmpty()
                if (dataset?.complete != true && tab in 1..3) tab = 0
            } catch (e: Exception) { dataset = GaitDataset(emptyList(), 0); error = e.message ?: "CSV error" }
            finally { loading = false }
        }
    }
    LaunchedEffect(Unit) { loadData() }
    DisposableEffect(Unit) { onDispose { transcriber?.cancel() } }

    val reportPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        val data = dataset
        if (uri != null && data != null && selected.isNotBlank()) scope.launch {
            try {
                val currentSubject = selected
                withContext(Dispatchers.IO) { PdfReport.save(context, uri, data, currentSubject, lang) }
                error = l(lang, "PDF-отчёт сохранён на устройстве", "PDF есебі құрылғыға сақталды")
            } catch (e: Exception) {
                error = (e.message ?: "PDF export error")
            }
        }
    }
    val csvPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            importMessage = ""
            try {
                val names = repository.importFiles(uris)
                importMessage = l(lang, "Импортировано: ", "Импортталды: ") + names.joinToString()
                loadData()
            } catch (e: Exception) { importMessage = e.message.orEmpty() }
        }
    }

    val startVoice: () -> Unit = {
        if (listening) {
            transcriber?.stop()
            listening = false
            voiceProcessing = true
            audioLevel = 0f
        } else if (!voiceProcessing) {
            transcriptionBase = chatInput.trimEnd().let { if (it.isBlank()) "" else "$it " }
            val onDelta: (String) -> Unit = { part -> ui.post { chatInput = transcriptionBase + part } }
            val onCompleted: (String) -> Unit = { final -> ui.post {
                chatInput = transcriptionBase + final
                listening = false
                voiceProcessing = false
                audioLevel = 0f
            } }
            val onLevel: (Float) -> Unit = { value -> ui.post { audioLevel = value } }
            val onFailure: (String) -> Unit = { reason -> ui.post {
                listening = false
                voiceProcessing = false
                audioLevel = 0f
                error = reason
            } }
            transcriber?.cancel()
            val service: VoiceSession = if (AiClient.hasVoiceKey) {
                voiceProvider = "OpenAI gpt-live-transcribe"
                LiveTranscriber(lang, onDelta, onCompleted, onLevel, onFailure)
            } else {
                voiceProvider = l(lang, "Системное распознавание Android", "Android жүйелік тануы")
                SystemSpeechTranscriber(context, lang, onDelta, onCompleted, onLevel, onFailure)
            }
            transcriber = service
            listening = true
            service.start()
        }
    }
    val microphonePermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startVoice() else error = l(lang,
            "Разрешите доступ к микрофону в настройках", "Баптаулардан микрофонға рұқсат беріңіз")
    }
    val onMicClick: () -> Unit = {
        if (listening || context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVoice()
        } else microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    val sendMessage: () -> Unit = send@{
        val text = chatInput.trim()
        val d = dataset
        if (text.isEmpty() || waiting || d == null) return@send
        transcriber?.cancel(); listening = false; voiceProcessing = false
        messages.add(true to text)
        chatInput = ""
        waiting = true
        val requestId = ++aiRequestId
        val subjectContext = GaitAnalytics.summary(d, selected, lang)
        scope.launch {
            try {
                val answer = AiClient.ask(text, lang, subjectContext)
                if (requestId == aiRequestId) messages.add(false to answer)
            } catch (e: Exception) {
                if (requestId == aiRequestId) messages.add(false to l(lang, "Ошибка подключения к ИИ: ",
                    "ЖИ-ға қосылу қатесі: ") + (e.message ?: "unknown"))
            } finally { if (requestId == aiRequestId) waiting = false }
        }
    }

    // Recordings must never continue invisibly after leaving the AI screen.
    LaunchedEffect(tab) {
        if (tab != 3) {
            transcriber?.cancel()
            listening = false
            voiceProcessing = false
            audioLevel = 0f
        }
    }

    LaunchedEffect(selected) {
        // Don't display an old participant's chat/late network reply for a new subject.
        aiRequestId++
        waiting = false
        messages.clear()
        transcriber?.cancel()
        listening = false
        voiceProcessing = false
    }

    // SanaCare-inspired light medical palette: mint + soft blue surfaces, not a dark dashboard.
    val lightScheme = lightColorScheme(primary = Color(0xFF0B8F80), secondary = Color(0xFF35B8A6),
        background = Color(0xFFF7FBFC), surface = Color.White, onSurface = Color(0xFF18343E),
        onSurfaceVariant = Color(0xFF68808A), surfaceVariant = Color(0xFFF1F8F7),
        outlineVariant = Color(0xFFE1ECEA))
    val darkScheme = darkColorScheme(primary = Color(0xFF52E2D0), secondary = Color(0xFF12C6B5),
        background = Color(0xFF091722), surface = Color(0xFF132735), onSurface = Color(0xFFF1FAFD),
        onSurfaceVariant = Color(0xFFB4C6CE), surfaceVariant = Color(0xFF1A3340),
        outlineVariant = Color(0xFF294553))
    val ready = dataset?.complete == true
    val safeTab = if (!ready && tab in 1..3) 0 else tab
    val helpSection = when (safeTab) {
        1 -> HelpSection.PARTICIPANTS
        2 -> HelpSection.ANALYSIS
        3 -> HelpSection.AI
        4 -> HelpSection.SETTINGS
        else -> HelpSection.HOME
    }
    val keyboardVisible = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val showCoach = !loading && !keyboardVisible &&
        (forceHelpFor == helpSection || (helpEnabled && helpSection !in seenHelp))
    LaunchedEffect(helpSection) {
        if (forceHelpFor != helpSection) forceHelpFor = null
    }
    val coach = CoachState(
        section = if (showCoach) helpSection else null,
        onSkip = {
            seenHelp = seenHelp + helpSection
            prefs.edit().putBoolean("inline_seen_${helpSection.name}", true).apply()
            forceHelpFor = null
        }
    )
    SideEffect {
        (context as? Activity)?.window?.let { win ->
            WindowCompat.getInsetsController(win, win.decorView).apply {
                isAppearanceLightStatusBars = !dark
                isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialTheme(colorScheme = if (dark) darkScheme else lightScheme) {
        CompositionLocalProvider(LocalCoach provides coach) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal))
            .navigationBarsPadding().imePadding()) {
            Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                if (!keyboardVisible) PremiumBottomBar(lang, safeTab, ready) { requested ->
                    if (requested in 1..3 && !ready) {
                        tab = 0
                        showImportRequired = true
                    } else tab = requested
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).consumeWindowInsets(padding)) {
                // Keep the chat composer and transcript available even on short screens.
                if (!(safeTab == 3 && keyboardVisible)) {
                    PremiumHeader(lang, selected, safeTab, ready,
                        onSettings = { tab = 4 },
                        onHelp = { forceHelpFor = helpSection })
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                if (loading) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Teal)
                            Spacer(Modifier.height(12.dp))
                            Text(l(lang, "Читаем реальные CSV...", "CSV деректерін оқудамыз..."))
                        }
                    }
                } else {
                    val data = dataset ?: GaitDataset(emptyList(), 0)
                    if (!data.complete && tab != 4) {
                        PremiumEmptyHome(lang, data.loadedFiles, importMessage,
                            onImport = { csvPicker.launch(arrayOf("*/*")) },
                            onSettings = { tab = 4 })
                    } else {
                        when (tab) {
                            0 -> PremiumDashboard(data, selected, lang,
                                onAnalyze = { tab = 2 }, onPatients = { tab = 1 },
                                onImport = { csvPicker.launch(arrayOf("*/*")) },
                                importMessage = importMessage)
                            1 -> PremiumPatients(data, selected, query, lang,
                                onQuery = { query = it }, onPick = { selected = it; tab = 2 })
                            2 -> PremiumAnalysis(data, selected, curveName, lang,
                                onCurve = { curveName = it }, onSubject = { selected = it },
                                onReport = {
                                    reportPicker.launch("VostokLab_${selected}_report.pdf")
                                })
                            3 -> PremiumAi(lang, selected, messages,
                                chatInput, onInput = { chatInput = it },
                                waiting, listening, voiceProcessing, voiceProvider, audioLevel, onMicClick, sendMessage,
                                keyboardVisible = keyboardVisible)
                            else -> PremiumSettings(lang, dark, data,
                                aiChecking = aiChecking, aiCheckMessage = aiCheckMessage,
                                helpEnabled = helpEnabled,
                                onHelpEnabled = { value ->
                                    helpEnabled = value
                                    prefs.edit().putBoolean("inline_help_enabled", value).apply()
                                    if (!value) forceHelpFor = null

                                },
                                onReplayGuide = {
                                    prefs.edit().apply {
                                        HelpSection.entries.forEach { remove("inline_seen_${it.name}") }
                                    }.apply()
                                    helpEnabled = true
                                    prefs.edit().putBoolean("inline_help_enabled", true).apply()
                                    seenHelp = emptySet()
                                    forceHelpFor = HelpSection.SETTINGS
                                },
                                onTestAi = {
                                    if (!aiChecking) scope.launch {
                                        aiChecking = true
                                        aiCheckMessage = null
                                        try {
                                            AiClient.ask("Проверь доступность модели. Данных исследования пока не передаю.",
                                                lang, "Тест подключения: медицинские CSV в этом запросе не отправляются.")
                                            aiCheckMessage = l(lang,
                                                "Соединение с OpenRouter установлено. Модель ответила.",
                                                "OpenRouter байланысы орнатылды. Модель жауап берді.")
                                        } catch (e: Exception) {
                                            aiCheckMessage = l(lang, "Проверка ИИ: ", "ЖИ тексеру: ") +
                                                (e.message ?: "Ошибка подключения")
                                        } finally { aiChecking = false }
                                    }
                                },
                                onLang = { lang = it; prefs.edit().putString("lang", it).apply() },
                                onDark = { dark = it; prefs.edit().putBoolean("dark", it).apply() },
                                onImport = { csvPicker.launch(arrayOf("*/*")) },
                                onReset = { scope.launch {
                                    repository.reset()
                                    dataset = GaitDataset(emptyList(), 0)
                                    selected = ""
                                    importMessage = l(lang, "Импортированные данные удалены", "Импортталған деректер өшірілді")
                                    tab = 0
                                } })
                        }
                    }
                }
                } // weighted screen content
            }
            if (showImportRequired) {
                AlertDialog(
                    onDismissRequest = { showImportRequired = false },
                    icon = { Icon(Icons.Default.FolderOpen, null, tint = MaterialTheme.colorScheme.primary) },
                    title = { Text(l(lang, "Сначала загрузите данные", "Алдымен деректерді жүктеңіз")) },
                    text = {
                        Text(l(lang,
                            "Разделы «Участники», «Анализ» и «ИИ» станут доступны после загрузки полного набора из 6 CSV. Можно выбрать исходный ZIP-архив или CSV-файлы.",
                            "«Қатысушылар», «Талдау» және «ЖИ» бөлімдері 6 CSV файлы жүктелгеннен кейін ашылады. ZIP мұрағатын немесе CSV файлдарын таңдаңыз."))
                    },
                    confirmButton = {
                        Button(onClick = {
                            showImportRequired = false
                            csvPicker.launch(arrayOf("*/*"))
                        }) { Text(l(lang, "Выбрать файлы", "Файлдарды таңдау")) }
                    },
                    dismissButton = {
                        TextButton(onClick = { showImportRequired = false }) {
                            Text(l(lang, "Позже", "Кейін"))
                        }
                    }
                )
            }
            if (error != null) {
                AlertDialog(onDismissRequest = { error = null }, title = {
                    Text(l(lang, "Сообщение", "Хабарлама"))
                }, text = { Text(error.orEmpty()) }, confirmButton = {
                    TextButton(onClick = { error = null }) { Text("OK") }
                })
            }
        }
        } // inset owner
        } // coach provider
    }
}
