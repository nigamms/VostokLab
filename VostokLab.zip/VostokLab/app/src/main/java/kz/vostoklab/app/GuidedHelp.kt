package kz.vostoklab.app

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal enum class HelpSection { HOME, PARTICIPANTS, ANALYSIS, AI, SETTINGS }
private fun tx(lang: String, ru: String, kk: String) = if (lang == "kk") kk else ru
private val helpAccent = Color(0xFF0A9C89)
private data class HelpCopy(val ruTitle: String, val kkTitle: String,
                            val ruBrief: String, val kkBrief: String,
                            val ruMore: String, val kkMore: String)

private fun helpContent(section: HelpSection): HelpCopy = when (section) {
    HelpSection.HOME -> HelpCopy(
        "Начните с загрузки данных", "Алдымен деректерді жүктеңіз",
        "Выберите исходный ZIP или шесть CSV на главной странице.",
        "Басты бетте ZIP мұрағатын немесе алты CSV файлын таңдаңыз.",
        "После успешной загрузки станут доступны участники, анализ графиков и ИИ. Данные изучаются локально на телефоне; неполный комплект не даёт делать полноценное сравнение.",
        "Толық жүктеуден кейін қатысушылар, графиктер мен ЖИ ашылады. Деректер телефонда талданады; толық емес жинақ дұрыс салыстыруға мүмкіндік бермейді.")
    HelpSection.PARTICIPANTS -> HelpCopy(
        "Найдите нужного участника", "Қажетті қатысушыны табыңыз",
        "Введите ID в поиске и нажмите карточку для анализа.",
        "Іздеуге ID енгізіп, талдау үшін карточканы басыңыз.",
        "В наборе данных обезличенные идентификаторы. Сравнивайте только исследуемую сторону (LEFT или RIGHT), указанную в записи.",
        "Деректерде жасырын идентификаторлар бар. Тек жазбада берілген зерттеу жағын (LEFT немесе RIGHT) салыстырыңыз.")
    HelpSection.ANALYSIS -> HelpCopy(
        "Выберите график", "Графикті таңдаңыз",
        "Нажмите на показатель, чтобы сменить график. Ниже — сводка изменений и GPS.",
        "Графикті ауыстыру үшін көрсеткішті басыңыз. Төменде өзгерістер мен GPS қорытындысы бар.",
        "Если разгибание бедра увеличилось, а GPS тоже вырос, возможны сопутствующие изменения других суставов. Это гипотеза, не доказанный диагноз. Сравнения описывают немедленную реакцию, не эффект лечения.",
        "Егер сан жазылуы артса, ал GPS те өссе, басқа буындардағы қатарлас өзгерістер болуы мүмкін. Бұл диагноз емес, болжам ғана. Салыстыру емнің әсерін емес, бірден болған реакцияны сипаттайды.")
    HelpSection.AI -> HelpCopy(
        "Спросите ИИ о показателях", "ЖИ-дан көрсеткіштер туралы сұраңыз",
        "Напишите вопрос или воспользуйтесь микрофоном. Сравните ответ с графиком.",
        "Сұрақ жазыңыз немесе микрофонды пайдаланыңыз. Жауапты графикпен салыстырыңыз.",
        "Ассистент получает рассчитанную сводку выбранного участника через интернет. Он может ошибаться, не ставит диагноз и не назначает лечение. Не отправляйте в чат персональные данные пациента.",
        "Көмекші интернет арқылы таңдалған қатысушының есептелген қорытындысын алады. Ол қателесуі мүмкін, диагноз қоймайды және ем тағайындамайды. Науқастың жеке деректерін жібермеңіз.")
    HelpSection.SETTINGS -> HelpCopy(
        "Настраивайте приложение под себя", "Қолданбаны өзіңізге ыңғайлаңыз",
        "Выберите язык и тему. Подсказки можно отключить в любой момент.",
        "Тіл мен тақырыпты таңдаңыз. Кеңестерді кез келген уақытта өшіруге болады.",
        "Нажмите знак вопроса в шапке для ручного показа подсказки. В этом разделе можно включить их повторно, проверить соединение с ИИ и очистить импортированные CSV.",
        "Кеңесті қайта ашу үшін жоғарғы сұрақ белгісін басыңыз. Бұл бетте кеңестерді қайта қосуға, ЖИ байланысын тексеруге және импортталған CSV деректерін өшіруге болады.")
}

/** The highlighted control remains clickable. The card is not a Dialog or a modal Popup. */
internal data class CoachState(val section: HelpSection?, val onSkip: () -> Unit)
internal val LocalCoach = compositionLocalOf { CoachState(null) {} }

@Composable
internal fun coachOutline(section: HelpSection, radius: Int = 18): Modifier {
    val active = LocalCoach.current.section == section
    return if (active) Modifier.border(2.dp, MaterialTheme.colorScheme.primary,
        RoundedCornerShape(radius.dp)).padding(3.dp) else Modifier
}

/** A floating-looking, anchored callout in normal content flow: no dimmer, focus trap or touch interception. */
@Composable
internal fun CoachCallout(lang: String, section: HelpSection, pointsDown: Boolean = false,
                          imported: Boolean = false, arrowAtStart: Boolean = false,
                          modifier: Modifier = Modifier) {
    val coach = LocalCoach.current
    if (coach.section != section) return
    val copy = helpContent(section)
    val title = if (section == HelpSection.HOME && imported)
        tx(lang, "Откройте анализ", "Талдауды ашыңыз") else tx(lang, copy.ruTitle, copy.kkTitle)
    val brief = if (section == HelpSection.HOME && imported)
        tx(lang, "Нажмите выделенную кнопку, чтобы сравнить три условия ходьбы.",
            "Жүрістің үш шартын салыстыру үшін белгіленген батырманы басыңыз.")
        else tx(lang, copy.ruBrief, copy.kkBrief)
    val accent = MaterialTheme.colorScheme.primary
    val cardColor = MaterialTheme.colorScheme.surface
    Column(modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        if (!pointsDown) {
            if (arrowAtStart) Box(Modifier.fillMaxWidth().padding(start = 72.dp)) { CoachArrow(accent, false) }
            else CoachArrow(accent, false)
        }
        Surface(shape = RoundedCornerShape(18.dp), color = cardColor,
            border = BorderStroke(1.dp, accent.copy(alpha = .7f)), shadowElevation = 5.dp,
            modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                Surface(shape = RoundedCornerShape(12.dp), color = accent.copy(alpha = .12f)) {
                    Icon(Icons.Default.Info, null, tint = accent,
                        modifier = Modifier.padding(9.dp).size(20.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(tx(lang, "ПОДСКАЗКА", "КЕҢЕС"), color = accent,
                        fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
                    Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface)
                    Text(brief, fontSize = 12.sp, lineHeight = 17.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = coach.onSkip,
                        modifier = Modifier.align(Alignment.End),
                        contentPadding = PaddingValues(horizontal = 10.dp)) {
                        Text(tx(lang, "Далее", "Келесі"), fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
        if (pointsDown) CoachArrow(accent, true)
    }
}

@Composable
private fun CoachArrow(color: Color, down: Boolean) {
    Canvas(Modifier.size(18.dp, 8.dp)) {
        val triangle = Path().apply {
            moveTo(0f, if (down) 0f else size.height)
            lineTo(size.width / 2f, if (down) size.height else 0f)
            lineTo(size.width, if (down) 0f else size.height)
            close()
        }
        drawPath(triangle, color)
    }
}

/** Expandable explanations under the data, not modal dialogs or invented clinical ratings. */
@Composable
internal fun DetailAccordion(lang: String, ruTitle: String, kkTitle: String,
                             ruBody: String, kkBody: String) {
    var expanded by remember(ruTitle) { mutableStateOf(false) }
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(Modifier.fillMaxWidth().clickable { expanded = !expanded }
                .padding(horizontal = 15.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.HelpOutline, null, tint = helpAccent, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(10.dp))
                Text(tx(lang, ruTitle, kkTitle), modifier = Modifier.weight(1f),
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Icon(if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    tx(lang, if (expanded) "Свернуть" else "Развернуть",
                        if (expanded) "Жасыру" else "Ашу"),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            AnimatedVisibility(visible = expanded) {
                Text(tx(lang, ruBody, kkBody),
                    modifier = Modifier.padding(start = 43.dp, end = 16.dp, bottom = 15.dp),
                    fontSize = 12.sp, lineHeight = 18.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

/** Research interpretation, ethics and methodology in concise on-demand sections. */
@Composable
internal fun ResearchHelpAccordions(lang: String, section: HelpSection) {
    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        when (section) {
            HelpSection.HOME -> {
                DetailAccordion(lang, "Что показывают эти данные?", "Бұл деректер нені көрсетеді?",
                    "Это открытый исследовательский набор ходьбы 29 участников в трёх условиях: Baseline, Verbal и VR. Мы показываем измерения, а не оцениваем лечение.",
                    "Бұл Baseline, Verbal және VR жағдайларындағы 29 қатысушының жүрісі туралы ашық зерттеу деректері. Қолданба емдеуді бағаламай, өлшемдерді көрсетеді.")
                DetailAccordion(lang, "Как использовать VostokLab?", "VostokLab қалай қолданылады?",
                    "Загрузите ZIP/6 CSV → выберите участника → сравните графики и сводку → при необходимости спросите ИИ → сохраните PDF. Врач проверяет и интерпретирует результат.",
                    "ZIP/6 CSV жүктеңіз → қатысушыны таңдаңыз → график пен қорытындыны салыстырыңыз → ЖИ-дан сұраңыз → PDF сақтаңыз. Нәтижені дәрігер тексереді.")
            }
            HelpSection.ANALYSIS -> {
                DetailAccordion(lang, "Почему цель и GPS могут расходиться?", "Неге мақсат пен GPS сәйкес келмеуі мүмкін?",
                    "Увеличение разгибания бедра при росте GPS может сопровождаться изменениями движений таза, колена и стопы. Это повод проверить GVS и кривые, а не утверждать доказанную компенсацию.",
                    "Сан жазылуы жақсарып, GPS өскенде жамбас, тізе және тобық қозғалысы да өзгеруі мүмкін. Бұл дәлелденген компенсация емес: GVS пен қисықтарды тексеру керек.")
                DetailAccordion(lang, "Как читать GPS и GVS?", "GPS және GVS қалай оқылады?",
                    "GPS — общий индекс отклонения походки от референсных кривых, GVS — отклонение для конкретной кинематической составляющей. Большая величина означает большее отклонение, но не ставит диагноз.",
                    "GPS — жүріс қисығының эталоннан жалпы ауытқу индексі, GVS — жеке кинематикалық көрсеткіш ауытқуы. Үлкен мән үлкен ауытқуды білдіреді, бірақ диагноз емес.")
                DetailAccordion(lang, "Откуда берутся средние и пропуски?", "Орташа мәндер мен бос орындар қайдан шығады?",
                    "На уровне участника используется среднее по его циклам; на уровне группы — среднее из средних по участникам, чтобы не переоценивать человека с большим числом циклов. NaN не заменяется нулём, экстремальные значения отмечаются для проверки.",
                    "Қатысушы деңгейінде циклдердің орташа мәні, топта — қатысушылардың орташалары алынады. NaN нөлге ауыстырылмайды, шектен тыс мәндер тексеру үшін белгіленеді.")
            }
            HelpSection.AI -> {
                DetailAccordion(lang, "Что получает ИИ?", "ЖИ қандай дерек алады?",
                    "ИИ получает вычисленную сводку выбранного анонимного участника, а не исходный ZIP. Ответы следует перепроверять по графикам и таблицам. Для работы нужен интернет.",
                    "ЖИ бастапқы ZIP емес, таңдалған жасырын қатысушының есептелген қорытындысын алады. Жауапты графикпен тексеру керек. Интернет қажет.")
                DetailAccordion(lang, "Безопасность и ограничения", "Қауіпсіздік пен шектеулер",
                    "Прототип не ставит диагноз, не назначает препараты и не доказывает эффективность лечения. Нельзя загружать идентифицирующие данные пациентов. Решение принимает врач.",
                    "Прототип диагноз қоймайды, дәрі тағайындамайды және ем тиімділігін дәлелдемейді. Пациенттің жеке деректерін жүктеуге болмайды. Шешімді дәрігер қабылдайды.")
            }
            HelpSection.SETTINGS -> {
                DetailAccordion(lang, "Данные и конфиденциальность", "Деректер мен құпиялық",
                    "В проекте допускаются только открытые, синтетические или полностью обезличенные данные. CSV обрабатываются локально. Текстовый ИИ отправляет вычисленную сводку через OpenRouter; ключ в APK нельзя считать защищённым.",
                    "Жоба тек ашық, синтетикалық немесе толық жасырылған деректермен жұмыс істейді. CSV телефонда талданады. Мәтіндік ЖИ OpenRouter арқылы есептелген қорытындыны жібереді; APK ішіндегі кілт қорғалған емес.")
                DetailAccordion(lang, "Откуда расчёты?", "Есептеулер қайдан алынады?",
                    "Показатели рассчитываются из загруженных CSV; пропуски NaN не подменяются. Сравнение отражает немедленную реакцию на обратную связь, но не долгосрочные клинические результаты. Источники и лицензии перечислены в документации проекта.",
                    "Көрсеткіштер жүктелген CSV-ден есептеледі; NaN мәндері ауыстырылмайды. Салыстыру ұзақ мерзімді ем нәтижесін емес, дереу реакцияны көрсетеді. Дереккөздер мен лицензиялар құжаттамада берілген.")
            }
            HelpSection.PARTICIPANTS -> Unit
        }
    }
}
