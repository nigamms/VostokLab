package kz.vostoklab.app

import java.io.Reader
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

/** Pure Kotlin data engine: safe to test without Android or network. */
enum class WalkCondition(val fileSuffix: String) {
    BASELINE("Baseline"), VERBAL("Verbal"), VR("VR")
}

enum class CsvKind(val prefix: String) {
    DISCRETE("Discrete_Parameters_"), WAVE("Kinematics_Kinetics_")
}

val DISCRETE_METRICS = listOf(
    "GPS_a", "GVS_aSagP", "GVS_aSagH", "GVS_aSagK", "GVS_aSagA",
    "aMinSagH", "pctmZeroStSagH"
)
val WAVE_METRICS = listOf("aSagP", "aSagH", "aSagK", "aSagA", "mSagH")

fun knownCsvFile(filename: String): Pair<CsvKind, WalkCondition>? =
    CsvKind.entries.flatMap { kind -> WalkCondition.entries.map { condition ->
        (kind to condition)
    } }.firstOrNull { (kind, condition) ->
        filename.equals("${kind.prefix}${condition.fileSuffix}.csv", ignoreCase = true)
    }

fun finiteNumber(s: String): Double? {
    val n = s.trim().replace(',', '.').toDoubleOrNull()
    return n?.takeIf { it.isFinite() }
}

data class Stats(
    val mean: Double?, val standardDeviation: Double?, val median: Double?,
    val mad: Double?, val anomalies: Int, val valid: Int, val missing: Int
)

private class NumericAccumulator {
    private val values = mutableListOf<Double>()
    var missing = 0
        private set
    fun add(value: Double?) {
        if (value == null) missing++ else values += value
    }
    fun finish(): Stats {
        if (values.isEmpty()) return Stats(null, null, null, null, 0, 0, missing)
        val mean = values.average()
        val stdev = sqrt(values.sumOf { (it - mean) * (it - mean) } / values.size)
        val sorted = values.sorted()
        val med = median(sorted)
        val mad = median(values.map { abs(it - med) }.sorted())
        // Robust modified Z: >3.5. A zero MAD cannot establish a robust outlier threshold.
        val n = if (mad > 1e-9) values.count { 0.6745 * abs(it - med) / mad > 3.5 } else 0
        return Stats(mean, stdev, med, mad, n, values.size, missing)
    }
    private fun median(xs: List<Double>): Double =
        if (xs.size % 2 == 0) (xs[xs.size / 2 - 1] + xs[xs.size / 2]) / 2
        else xs[xs.size / 2]
}

private class CurveAccumulator {
    private val sums = DoubleArray(51)
    private val counts = IntArray(51)
    fun add(i: Int, v: Double?) {
        if (v != null) { sums[i] += v; counts[i]++ }
    }
    fun finish(): List<Double?> = (0..50).map { i ->
        if (counts[i] == 0) null else sums[i] / counts[i]
    }
}

private data class GroupKey(val subject: String, val side: String, val condition: WalkCondition)

private class GroupBuilder(val key: GroupKey) {
    val metrics = DISCRETE_METRICS.associateWith { NumericAccumulator() }
    val curves = WAVE_METRICS.associateWith { CurveAccumulator() }
    var discreteCycles: Int = 0
    var waveCycles: Int = 0
    fun finish() = GaitRecord(
        subject = key.subject, side = key.side, condition = key.condition,
        cycleCount = discreteCycles,
        curveCycleCount = waveCycles,
        metrics = metrics.mapValues { it.value.finish() },
        curves = curves.mapValues { it.value.finish() }
    )
}

data class GaitRecord(
    val subject: String, val side: String, val condition: WalkCondition,
    val cycleCount: Int, val curveCycleCount: Int,
    val metrics: Map<String, Stats>, val curves: Map<String, List<Double?>>
) {
    fun metric(name: String): Double? = metrics[name]?.mean
}

data class GaitDataset(val records: List<GaitRecord>, val loadedFiles: Int) {
    val subjects: List<String> = records.map { it.subject }.distinct().sortedWith(
        compareBy { it.substringAfterLast('_').toIntOrNull() ?: Int.MAX_VALUE }
    )
    fun find(subject: String, condition: WalkCondition): GaitRecord? =
        records.firstOrNull { it.subject == subject && it.condition == condition }
    val totalCycles: Int get() = records.sumOf { it.cycleCount }
    val complete: Boolean get() = loadedFiles == 6 && records.size == subjects.size * 3
}

class GaitParser {
    private val groups = linkedMapOf<GroupKey, GroupBuilder>()
    private val loaded = mutableSetOf<Pair<CsvKind, WalkCondition>>()

    fun addCsv(fileName: String, reader: Reader) {
        val pair = knownCsvFile(fileName) ?: error("Unsupported CSV filename: $fileName")
        require(pair !in loaded) { "Duplicate CSV source: $fileName" }
        val (kind, condition) = pair
        val lines = reader.buffered()
        val header = (lines.readLine() ?: error("Empty CSV: $fileName"))
            .removePrefix("\uFEFF").split(';').map { it.trim() }
        val index = header.withIndex().associate { it.value to it.index }
        val required = listOf("subject", "side") + if (kind == CsvKind.DISCRETE) {
            DISCRETE_METRICS
        } else {
            WAVE_METRICS.flatMap { m -> (0..50).map { k -> "${m}_pct_GC_${k * 20}" } }
        }
        require(required.all { it in index }) { "Columns missing in $fileName: ${required.filterNot { it in index }}" }
        var n = 0
        while (true) {
            val line = lines.readLine() ?: break
            if (line.isBlank()) continue
            val tokens = line.split(';')
            require(tokens.size == header.size) { "Malformed CSV row ${n + 2} in $fileName" }
            fun token(name: String) = tokens[index.getValue(name)].trim().trim('"')
            val subject = token("subject")
            val side = token("side").uppercase(Locale.ROOT)
            require(subject.isNotBlank() && side in setOf("LEFT", "RIGHT")) {
                "Invalid subject or side in $fileName line ${n + 2}"
            }
            val builder = groups.getOrPut(GroupKey(subject, side, condition)) {
                GroupBuilder(GroupKey(subject, side, condition))
            }
            if (kind == CsvKind.DISCRETE) {
                builder.discreteCycles++
                for (m in DISCRETE_METRICS) builder.metrics.getValue(m).add(finiteNumber(token(m)))
            } else {
                builder.waveCycles++
                for (m in WAVE_METRICS) for (i in 0..50) {
                    builder.curves.getValue(m).add(i, finiteNumber(token("${m}_pct_GC_${i * 20}")))
                }
            }
            n++
        }
        require(n > 0) { "CSV contains no rows: $fileName" }
        loaded += pair
    }

    fun build(): GaitDataset = GaitDataset(groups.values.map { it.finish() }, loaded.size)
}

/** Explanation-ready, reproducible descriptive analytics; no clinical diagnosis. */
object GaitAnalytics {
    fun delta(previous: Double?, current: Double?): Double? =
        if (previous == null || current == null) null else current - previous

    fun percentChange(previous: Double?, current: Double?): Double? =
        if (previous == null || current == null || abs(previous) < 1e-10) null
        else (current - previous) / abs(previous) * 100

    /** Average across participants (equal subject weights), not across all gait cycles. */
    fun cohortMean(data: GaitDataset, condition: WalkCondition, metric: String): Double? {
        val perSubject = data.subjects.mapNotNull { subject ->
            data.find(subject, condition)?.metric(metric)
        }
        return if (perSubject.isEmpty()) null else perSubject.average()
    }

    fun metricMean(data: GaitDataset, subject: String?, condition: WalkCondition,
                   metric: String): Double? = if (subject == null) cohortMean(data, condition, metric)
    else data.find(subject, condition)?.metric(metric)

    // These labels describe changes in measurements only, not health, clinical importance or diagnoses.
    enum class Change { CLOSER, FURTHER, MORE_EXTENSION, LESS_EXTENSION, STABLE, UNKNOWN, NO_DATA }
    fun classify(metric: String, baseline: Double?, current: Double?): Change {
        val diff = delta(baseline, current) ?: return Change.NO_DATA
        if (abs(diff) < 0.005) return Change.STABLE // negligible at displayed precision (0.01)
        return when (metric) {
            "GPS_a", "GVS_aSagP", "GVS_aSagH", "GVS_aSagK", "GVS_aSagA" ->
                if (diff < 0) Change.CLOSER else Change.FURTHER
            "aMinSagH" -> if (diff < 0) Change.MORE_EXTENSION else Change.LESS_EXTENSION
            else -> Change.UNKNOWN // no evidence that larger/smaller means better
        }
    }

    /** When target hip extension rises but global gait deviation worsens, compensation is a hypothesis. */
    fun compensationFlag(data: GaitDataset, subject: String?, condition: WalkCondition): Boolean {
        val bHip = metricMean(data, subject, WalkCondition.BASELINE, "aMinSagH")
        val newHip = metricMean(data, subject, condition, "aMinSagH")
        val bGps = metricMean(data, subject, WalkCondition.BASELINE, "GPS_a")
        val newGps = metricMean(data, subject, condition, "GPS_a")
        return classify("aMinSagH", bHip, newHip) == Change.MORE_EXTENSION &&
            classify("GPS_a", bGps, newGps) == Change.FURTHER
    }

    fun evidenceSummary(data: GaitDataset, subject: String?, condition: WalkCondition,
                        lang: String): String {
        val kz = lang == "kk"
        val context = if (subject == null) {
            if (kz) "29 қатысушының топтық орташа мәндері (алдымен әр қатысушы бойынша)" else
                "Групповые средние по участникам, а не по всем циклам"
        } else if (kz) "${subject} қатысушысының циклдері бойынша орташа" else
            "Средние по циклам участника $subject"
        fun comparison(metric: String): String {
            val b = metricMean(data, subject, WalkCondition.BASELINE, metric)
            val c = metricMean(data, subject, condition, metric)
            return if (b == null || c == null) "$metric: NaN" else
                "$metric: Baseline ${b.format(2)}, ${condition.fileSuffix} ${c.format(2)}; delta=${(c-b).format(2)}"
        }
        return buildString {
            append(context).append("\n")
            append(comparison("aMinSagH")).append("\n")
            append(comparison("GPS_a")).append("\n")
            for (metric in listOf("GVS_aSagP", "GVS_aSagH", "GVS_aSagK", "GVS_aSagA"))
                append(comparison(metric)).append("\n")
            val hypothesis = compensationFlag(data, subject, condition)
            append(if (kz) {
                if (hypothesis) "Санның жазылуы артты, бірақ GPS өсті: басқа буындарда компенсациялық өзгерістер болуы мүмкін; бұл дәлелденген диагноз емес."
                else "Мақсатты параметр мен жалпы GPS бөлек бағаланады; емдеу қорытындысын автоматты түрде шығаруға болмайды."
            } else {
                if (hypothesis) "Разгибание бедра увеличилось, однако GPS вырос: возможны компенсаторные изменения в других суставах; это гипотеза, не доказанная причина."
                else "Целевой угол и общий GPS оцениваются раздельно; автоматические выводы об эффективности лечения недопустимы."
            })
            append(if (kz) " Шешімді дәрігер қабылдайды; ұзақ мерзімді әсер зерттелмеген."
                else " Решение принимает врач; долгосрочный эффект здесь не измерялся.")
        }
    }

    fun summary(data: GaitDataset, subject: String, lang: String): String {
        val base = data.find(subject, WalkCondition.BASELINE) ?: return "No data"
        val records = WalkCondition.entries.mapNotNull { data.find(subject, it) }
        val kz = lang == "kk"
        return buildString {
            append(if (kz) "Қатысушы: " else "Участник: ")
            append(subject).append("; ")
            append(if (kz) "жақ: " else "сторона: ").append(base.side).append("\n")
            for (record in records) {
                append("${record.condition.fileSuffix}: ${record.cycleCount} ")
                append(if (kz) "қадам циклі" else "циклов шага").append("\n")
                DISCRETE_METRICS.forEach { metric ->
                    val stat = record.metrics[metric]!!
                    append("  $metric=").append(stat.mean?.format(2) ?: "NaN")
                    append("; SD=").append(stat.standardDeviation?.format(2) ?: "NaN")
                    append("; n=").append(stat.valid)
                    if (stat.missing > 0) append("; missing=${stat.missing}")
                    if (metric == "GPS_a") append("; MAD-outliers=${stat.anomalies}")
                    append("\n")
                }
                // Add curve summaries so the LLM can answer questions about actual gait waveforms.
                // Do not transmit full raw cycle tables: only derived mean curves.
                WAVE_METRICS.forEach { feature ->
                    val points = record.curves[feature].orEmpty()
                    val known = points.mapIndexedNotNull { index, value ->
                        value?.let { (index * 2) to it }
                    }
                    if (known.isNotEmpty()) {
                        val smallest = known.minBy { it.second }
                        val largest = known.maxBy { it.second }
                        append("  $feature mean-curve: n=${known.size}/51")
                        append("; min=${smallest.second.format(2)} at ${smallest.first}%")
                        append("; max=${largest.second.format(2)} at ${largest.first}%")
                        append("; start=${points.firstOrNull()?.format(2) ?: "NaN"}")
                        append("; end=${points.lastOrNull()?.format(2) ?: "NaN"}\n")
                    }
                }
            }
            append(if (kz) "Baseline-пен салыстырғандағы айырмашылықтар:\n"
                else "Разницы относительно Baseline:\n")
            for (r in records.filter { it.condition != WalkCondition.BASELINE }) {
                for (m in DISCRETE_METRICS) {
                    val v = delta(base.metric(m), r.metric(m))
                    append("${r.condition.fileSuffix} $m delta=")
                    append(v?.format(2) ?: "нет данных").append("\n")
                }
            }
            for (condition in listOf(WalkCondition.VERBAL, WalkCondition.VR)) {
                append("\n").append(evidenceSummary(data, subject, condition, lang)).append("\n")
            }
            append("\n")
            append(if (kz) "Топтық деңгей (бір қатысушының нәтижесі емес):\n" else "Данные всей группы (не одного ребёнка):\n")
            for (condition in listOf(WalkCondition.VERBAL, WalkCondition.VR)) {
                append(evidenceSummary(data, null, condition, lang)).append("\n")
            }
            append(if (kz)
                "Маңызды: тек дереу әсерлер, диагноз немесе ұзақ мерзімді нәтиже емес."
            else "Важно: только немедленные эффекты; это не диагноз и не долгосрочный результат.")
        }
    }
}

fun Double.format(digits: Int = 2): String = "% .${digits}f".trim().let { mask ->
    String.format(Locale.US, mask, this).trim()
}
