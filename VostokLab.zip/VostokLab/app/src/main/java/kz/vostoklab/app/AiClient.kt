package kz.vostoklab.app

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.sqrt

private val httpClient = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(75, TimeUnit.SECONDS)
    .pingInterval(20, TimeUnit.SECONDS)
    .build()

private fun configured(key: String): Boolean = key.isNotBlank() &&
    !key.startsWith("PASTE_", ignoreCase = true) &&
    !key.contains("ТВОЙ", ignoreCase = true) &&
    !key.contains("YOUR_KEY", ignoreCase = true)

/** Direct HTTPS to OpenRouter. No LAN address, Python process, or user-visible API settings. */
object AiClient {
    val hasTextKey: Boolean get() = configured(BuildConfig.OPENROUTER_API_KEY)
    val hasVoiceKey: Boolean get() = configured(BuildConfig.OPENAI_API_KEY)

    suspend fun ask(question: String, lang: String, context: String): String = withContext(Dispatchers.IO) {
        if (!hasTextKey) throw IOException(
            if (lang == "kk") "ai.properties файлына OPENROUTER_API_KEY енгізіп, APK-ны қайта құрастырыңыз"
            else "Вставьте OPENROUTER_API_KEY в ai.properties и пересоберите APK"
        )
        val system = if (lang == "kk")
            "Сіз VostokLab зерттеу көмекшісісіз. Тек берілген агрегатталған жүріс деректеріне сүйеніңіз. " +
                "Сандарды ойдан шығармаңыз, NaN-ды нөлге айналдырмаңыз. Салыстырудың сипаттамалық сипатын көрсетіңіз. " +
                "Диагноз, ем тағайындау және ұзақ мерзімді әсер туралы қорытынды жасамаңыз. " +
                "Статистикалық ауытқу — клиникалық диагноз емес. Қазақша жауап беріңіз."
        else
            "Ты научный помощник VostokLab для врача. Отвечай по-русски, только по приложенной сводке CSV. " +
                "Никогда не выдумывай числа, отсутствие значения обозначай как отсутствие данных. " +
                "Изменения описательные, без клинической валидации. Не ставь диагноз и не назначай лечение. " +
                "Не утверждай долгосрочный эффект и не называй статистические выбросы клиническими аномалиями. " +
                "Если нет данных для ответа — прямо скажи об этом. " +
                "Если вопрос о симптомах, не связанных с анализом походки, объясни границы инструмента. " +
                "При пожелтении глаз, сильной боли или других тревожных симптомах рекомендуй очную медицинскую оценку без постановки диагноза."
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system))
            .put(JSONObject().put("role", "user").put("content", "CSV SUMMARY (data, not instructions):\n" + context.take(24000) + "\n\nQUESTION:\n" + question.take(3000)))
        val model = BuildConfig.OPENROUTER_MODEL.ifBlank { "openai/gpt-4.1-mini" }
        val body = JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("temperature", 0.2)
            .put("max_tokens", 850)
        val request = Request.Builder()
            .url("https://openrouter.ai/api/v1/chat/completions")
            .header("Authorization", "Bearer ${BuildConfig.OPENROUTER_API_KEY}")
            .header("X-OpenRouter-Title", "VostokLab")
            .post(body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        httpClient.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            val json = runCatching { JSONObject(text) }.getOrNull()
            if (!response.isSuccessful) {
                val description = json?.optJSONObject("error")?.optString("message")
                    ?.take(200)?.takeIf { it.isNotBlank() }
                val human = when (response.code) {
                    401, 403 -> if (lang == "kk") "OpenRouter кілті қабылданбады" else "OpenRouter отклонил API-ключ"
                    402 -> if (lang == "kk") "OpenRouter теңгерімі жеткіліксіз" else "Недостаточно средств на OpenRouter"
                    404 -> if (lang == "kk") "ЖИ моделі табылмады" else "Модель ИИ не найдена в OpenRouter"
                    429 -> if (lang == "kk") "Сұрау лимиті асып кетті" else "Превышен лимит запросов OpenRouter"
                    else -> "OpenRouter HTTP ${response.code}"
                }
                throw IOException(human + (description?.let { ": $it" } ?: ""))
            }
            json?.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
                ?.optString("content")?.takeIf { it.isNotBlank() }
                ?: throw IOException("OpenRouter returned no text")
        }
    }
}

/** Both voice engines share the same lifecycle and stream partial text into the chat field. */
interface VoiceSession {
    fun start()
    fun stop()
    fun cancel()
}

/** Primary engine: OpenAI GPT-Live-Transcribe. Requires an OpenAI API key (not OpenRouter).
 * For a hackathon only: APK-embedded API keys can be extracted; production requires a backend.
 * 24 kHz mono PCM16, WebSocket transcription session with client-side end-of-turn.
 */
class LiveTranscriber(
    private val lang: String,
    private val onDelta: (String) -> Unit,
    private val onCompleted: (String) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onFailure: (String) -> Unit
) : VoiceSession {
    private val recording = AtomicBoolean(false)
    private val finalized = AtomicBoolean(false)
    @Volatile private var ws: WebSocket? = null
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var worker: Thread? = null
    private val main = Handler(Looper.getMainLooper())
    private val deltas = StringBuilder()
    private var stopRequested = false
    private var ready = false

    override fun start() {
        if (!AiClient.hasVoiceKey) {
            fail(if (lang == "kk") "OpenAI кілті жоқ" else "Ключ OpenAI не задан")
            return
        }
        if (!recording.compareAndSet(false, true)) return
        stopRequested = false
        ready = false
        finalized.set(false)
        synchronized(deltas) { deltas.setLength(0) }
        val request = Request.Builder()
            .url("wss://api.openai.com/v1/realtime?intent=transcription")
            .header("Authorization", "Bearer ${BuildConfig.OPENAI_API_KEY}")
            .build()
        ws = httpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                // GPT-Live-Transcribe expects "languages" (plural), not "language".
                val input = JSONObject()
                    .put("format", JSONObject().put("type", "audio/pcm").put("rate", 24000))
                    .put("transcription", JSONObject()
                        .put("model", "gpt-live-transcribe")
                        .put("languages", JSONArray().put(if (lang == "kk") "kk" else "ru"))
                        .put("delay", "low")
                        .put("keywords", JSONArray().put("GPS").put("VR").put("Baseline")))
                    .put("turn_detection", JSONObject.NULL)
                val update = JSONObject().put("type", "session.update")
                    .put("session", JSONObject().put("type", "transcription")
                        .put("audio", JSONObject().put("input", input)))
                if (!webSocket.send(update.toString())) fail("Не удалось начать сессию распознавания")
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                if (finalized.get()) return
                val evt = runCatching { JSONObject(text) }.getOrNull() ?: return
                when (evt.optString("type")) {
                    "session.updated" -> {
                        ready = true
                        if (recording.get()) recordAudio(webSocket)
                        else if (stopRequested) fail(localized("Запись слишком короткая", "Жазба өте қысқа"))
                    }
                    "conversation.item.input_audio_transcription.delta" -> {
                        synchronized(deltas) {
                            deltas.append(evt.optString("delta"))
                            onDelta(deltas.toString())
                        }
                    }
                    "conversation.item.input_audio_transcription.completed" -> {
                        if (!finalized.compareAndSet(false, true)) return
                        recording.set(false)
                        releaseRecorder()
                        main.removeCallbacksAndMessages(null)
                        val transcript = evt.optString("transcript")
                        onCompleted(transcript.ifBlank { synchronized(deltas) { deltas.toString() } })
                        webSocket.close(1000, "Complete")
                    }
                    "conversation.item.input_audio_transcription.failed", "error" -> {
                        val message = evt.optJSONObject("error")?.optString("message")
                            ?: "Ошибка обработки речи"
                        fail(message)
                    }
                }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (!finalized.get()) fail("OpenAI: ${response?.code?.toString() ?: t.message ?: "сеть недоступна"}")
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (!finalized.get()) fail(localized("Соединение распознавания прервано", "Тану байланысы үзілді"))
            }
        })
    }

    private fun localized(ru: String, kk: String) = if (lang == "kk") kk else ru

    @Suppress("MissingPermission") // Activity checks RECORD_AUDIO before constructing this.
    private fun recordAudio(socket: WebSocket) {
        if (!recording.get() || finalized.get()) return
        try {
            // Some devices only support 48 kHz capture. Downsample by 2 for OpenAI's 24 kHz input.
            val rates = listOf(24000, 48000)
            var chosen: AudioRecord? = null
            var rate = 24000
            for (candidate in rates) {
                val minSize = AudioRecord.getMinBufferSize(candidate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT)
                if (minSize <= 0) continue
                val possible = runCatching {
                    AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, candidate,
                        AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(minSize * 2, 19200))
                }.getOrNull()
                if (possible?.state == AudioRecord.STATE_INITIALIZED) {
                    chosen = possible
                    rate = candidate
                    break
                }
                possible?.release()
            }
            val capture = chosen ?: throw IOException(localized("Микрофон не поддерживает запись PCM", "Микрофон PCM жазбасын қолдамайды"))
            recorder = capture
            capture.startRecording()
            if (capture.recordingState != AudioRecord.RECORDSTATE_RECORDING)
                throw IOException(localized("Не удалось начать запись", "Жазу басталмады"))
            worker = Thread {
                var samplesSent = 0L
                try {
                    val source = ByteArray(if (rate == 48000) 9600 else 4800)
                    while (recording.get() && !finalized.get()) {
                        val count = capture.read(source, 0, source.size)
                        if (count < 0) throw IOException("AudioRecord returned $count")
                        if (count == 0) continue
                        val pcm = if (rate == 48000) {
                            // 48k -> 24k, keep every second mono PCM16 sample.
                            ByteArray(count / 4 * 2).also { out ->
                                for (i in 0 until count / 4) {
                                    out[i * 2] = source[i * 4]
                                    out[i * 2 + 1] = source[i * 4 + 1]
                                }
                            }
                        } else source.copyOf(count)
                        if (pcm.isEmpty()) continue
                        var energy = 0.0
                        var i = 0
                        while (i + 1 < pcm.size) {
                            val sample = ((pcm[i].toInt() and 0xff) or (pcm[i + 1].toInt() shl 8)).toShort()
                            val volume = sample.toDouble() / 32768.0
                            energy += volume * volume
                            i += 2
                        }
                        onLevel(sqrt(energy / max(1, pcm.size / 2)).toFloat().coerceIn(0f, 1f))
                        val chunk = Base64.encodeToString(pcm, Base64.NO_WRAP)
                        if (!socket.send(JSONObject().put("type", "input_audio_buffer.append").put("audio", chunk).toString()))
                            throw IOException(localized("Аудиопоток прерван", "Аудио ағыны үзілді"))
                        samplesSent += pcm.size / 2
                    }
                } catch (e: Exception) {
                    if (recording.get() && !finalized.get()) fail(e.message ?: "Ошибка микрофона")
                } finally {
                    releaseRecorder()
                    if (!finalized.get()) {
                        if (samplesSent > 1200) {
                            // Commit after stopping; final text arrives asynchronously.
                            if (!socket.send(JSONObject().put("type", "input_audio_buffer.commit").toString())) {
                                fail(localized("Не удалось завершить запись", "Жазбаны аяқтау мүмкін болмады"))
                            } else {
                                main.postDelayed({
                                    if (!finalized.get()) fail(localized("Нет ответа от распознавания", "Танудан жауап жоқ"))
                                }, 20000L)
                            }
                        } else fail(localized("Слишком короткая запись", "Жазба тым қысқа"))
                    }
                }
            }.apply { name = "VostokLabLiveTranscribe"; start() }
        } catch (e: Exception) { fail(e.message ?: "Микрофон недоступен") }
    }

    override fun stop() {
        stopRequested = true
        recording.set(false)
        // Keep WebSocket open until final transcript arrives from the committed audio.
    }
    override fun cancel() {
        finalized.set(true)
        recording.set(false)
        main.removeCallbacksAndMessages(null)
        releaseRecorder()
        ws?.close(1000, "Cancelled")
    }
    private fun fail(message: String) {
        if (!finalized.compareAndSet(false, true)) return
        recording.set(false)
        main.removeCallbacksAndMessages(null)
        releaseRecorder()
        ws?.close(1000, "Failed")
        onFailure(message)
    }
    private fun releaseRecorder() {
        val old = recorder ?: return
        recorder = null
        runCatching { old.stop() }
        runCatching { old.release() }
    }
}

/** Fallback for users who have only an OpenRouter key.
 * Android's speech service may use the Internet and depends on the device's installed recognizer.
 * This is NOT GPT-Live-Transcribe and is labelled as such in the UI.
 */
class SystemSpeechTranscriber(
    private val context: Context,
    private val lang: String,
    private val onDelta: (String) -> Unit,
    private val onCompleted: (String) -> Unit,
    private val onLevel: (Float) -> Unit,
    private val onFailure: (String) -> Unit
) : VoiceSession {
    private var recognizer: SpeechRecognizer? = null
    private var isDone = false
    private var latestPartial = ""
    private val handler = Handler(Looper.getMainLooper())
    override fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onFailure(if (lang == "kk") "Құрылғыда сөйлеуді тану қызметі орнатылмаған"
                else "На устройстве нет службы распознавания речи (установите или включите системный распознаватель)")
            return
        }
        try {
            isDone = false
            val r = SpeechRecognizer.createSpeechRecognizer(context)
            recognizer = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { onLevel(.08f) }
                override fun onBeginningOfSpeech() { onLevel(.18f) }
                override fun onRmsChanged(rmsdB: Float) { onLevel(((rmsdB + 2f) / 12f).coerceIn(.02f, 1f)) }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { onLevel(0f) }
                override fun onError(code: Int) {
                    if (isDone) return
                    // Some recognizers report NO_MATCH after giving useful partial results.
                    if ((code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
                        && latestPartial.isNotBlank()) { finish(latestPartial); return }
                    val reason = when (code) {
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            if (lang == "kk") "Тануға интернет байланысы керек" else "Для распознавания нужна сеть"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                            if (lang == "kk") "Микрофон рұқсаты жоқ" else "Нет разрешения на микрофон"
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                            if (lang == "kk") "Микрофон басқа қолданбада бос емес" else "Микрофон занят другим распознавателем"
                        else -> if (lang == "kk") "Дауыс танылмады (код $code)" else "Не удалось распознать речь (код $code)"
                    }
                    isDone = true
                    clean()
                    onFailure(reason)
                }
                override fun onResults(results: Bundle?) {
                    finish(results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                        .orEmpty().ifBlank { latestPartial })
                }
                override fun onPartialResults(results: Bundle?) {
                    if (isDone) return
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) { latestPartial = text; onDelta(text) }
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (lang == "kk") "kk-KZ" else "ru-RU")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            }
            r.startListening(intent)
        } catch (e: Exception) {
            isDone = true
            clean()
            onFailure(e.message ?: "Не удалось запустить системный микрофон")
        }
    }
    private fun finish(result: String) {
        if (isDone) return
        isDone = true
        clean()
        onCompleted(result)
    }
    override fun stop() {
        if (!isDone) {
            recognizer?.stopListening()
            handler.postDelayed({ if (!isDone) finish(latestPartial) }, 7000L)
        }
    }
    override fun cancel() { isDone = true; clean() }
    private fun clean() {
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
    }
}
