@echo off
setlocal
REM Lightweight Windows Gradle launcher. Downloads official Gradle on first run.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\gradle-bootstrap.ps1" %*
exit /b %ERRORLEVEL%
