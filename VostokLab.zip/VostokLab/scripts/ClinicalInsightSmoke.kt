import kz.vostoklab.app.*
import java.io.File
import kotlin.math.abs
fun near(x:Double?, expected:Double, tol:Double=0.03):Boolean = x != null && abs(x-expected)<tol
fun main(args:Array<String>){
    val parser = GaitParser()
    File(args[0]).listFiles()!!.filter{it.name.endsWith(".csv")}.forEach { f ->
      f.reader().use{parser.addCsv(f.name,it)}
    }
    val data = parser.build()
    check(data.complete && data.subjects.size==29 && data.totalCycles==2606)
    check(near(GaitAnalytics.cohortMean(data,WalkCondition.BASELINE,"aMinSagH"),6.17))
    check(near(GaitAnalytics.cohortMean(data,WalkCondition.VERBAL,"aMinSagH"),2.67))
    check(near(GaitAnalytics.cohortMean(data,WalkCondition.VR,"aMinSagH"),2.00))
    check(near(GaitAnalytics.cohortMean(data,WalkCondition.BASELINE,"GPS_a"),9.98))
    check(near(GaitAnalytics.cohortMean(data,WalkCondition.VERBAL,"GPS_a"),11.07))
    check(near(GaitAnalytics.cohortMean(data,WalkCondition.VR,"GPS_a"),10.89))
    check(GaitAnalytics.compensationFlag(data,null,WalkCondition.VR))
    check(GaitAnalytics.compensationFlag(data,null,WalkCondition.VERBAL))
    check(GaitAnalytics.classify("GPS_a",12.0,10.0)==GaitAnalytics.Change.CLOSER)
    check(GaitAnalytics.classify("GPS_a",10.0,12.0)==GaitAnalytics.Change.FURTHER)
    check(GaitAnalytics.classify("aMinSagH",6.0,2.0)==GaitAnalytics.Change.MORE_EXTENSION)
    check(GaitAnalytics.classify("pctmZeroStSagH",10.0,9.0)==GaitAnalytics.Change.UNKNOWN)
    check(GaitAnalytics.classify("GPS_a",null,1.0)==GaitAnalytics.Change.NO_DATA)
    println("PASS: 29 subjects, 2606 gait cycles, cohort averages and compensation pattern")
    println(GaitAnalytics.evidenceSummary(data,null,WalkCondition.VR,"ru"))
}
