"""Optional baseline experiment, NOT a validated clinical model.

Usage: python scripts/evaluate_classifier.py --csv-dir "D:/path/to/extracted/csv"
A participant may occur in exactly one fold per split; imputation and scaling
are fitted inside the train fold only. Requires separately supplied CSVs.
NO research CSVs are bundled into this application.
"""
import csv
from pathlib import Path
import argparse
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, balanced_accuracy_score, classification_report
from sklearn.model_selection import GroupKFold, cross_val_predict
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
METRICS = ["GPS_a", "GVS_aSagP", "GVS_aSagH", "GVS_aSagK", "GVS_aSagA", "aMinSagH", "pctmZeroStSagH"]


def load(directory: Path):
    samples, labels, groups = [], [], []
    for condition in ("Baseline", "Verbal", "VR"):
        path = directory / f"Discrete_Parameters_{condition}.csv"
        with path.open(encoding="utf-8-sig", newline="") as handle:
            for row in csv.DictReader(handle, delimiter=";"):
                samples.append([float(row[field].replace(",", ".")) if row[field].strip() and row[field].strip().lower() != "nan" else float("nan") for field in METRICS])
                labels.append(condition)
                groups.append(row["subject"])
    return np.array(samples), np.array(labels), np.array(groups)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv-dir", required=True, type=Path,
                        help="Directory containing original extracted Discrete_Parameters_*.csv")
    args = parser.parse_args()
    x, y, group = load(args.csv_dir)
    splits = GroupKFold(n_splits=5)
    for train, test in splits.split(x, y, groups=group):
        assert set(group[train]).isdisjoint(set(group[test])), "Participant leakage!"
    pipeline = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(),
                             LogisticRegression(max_iter=2000))
    predictions = cross_val_predict(pipeline, x, y, groups=group, cv=splits)
    print(f"Samples: {len(x)}; subjects: {len(set(group))}; 5-fold GroupKFold")
    print(f"Accuracy: {accuracy_score(y, predictions):.4f}")
    print(f"Balanced accuracy: {balanced_accuracy_score(y, predictions):.4f}")
    print(classification_report(y, predictions, digits=3))
    print("NOTE: Not a clinical-quality classification; do not present as diagnosis.")


if __name__ == "__main__":
    main()
