import kz.vostoklab.app.*
import java.io.File
fun main(args: Array<String>) {
    val parser = GaitParser()
    for (file in File(args[0]).listFiles()!!.filter { it.name.endsWith(".csv") }) {
        file.reader(Charsets.UTF_8).use { parser.addCsv(file.name, it) }
    }
    val data = parser.build()
    check(data.complete)
    check(data.subjects.size == 29)
    check(data.totalCycles == 2606)
    check(data.records.size == 87)
    val missing = data.find("s61520_22", WalkCondition.BASELINE)?.metrics?.get("pctmZeroStSagH")
    check(missing?.valid == 0 && missing.missing == 30)
    val wave = data.find("s61520_1", WalkCondition.BASELINE)!!.curves.getValue("aSagH")
    check(wave.size == 51 && wave.any { it != null })
    println("SUCCESS: ${data.subjects.size} participants; ${data.records.size} rows; ${data.totalCycles} cycles; 6 CSV; missing values handled")
    println(GaitAnalytics.summary(data, "s61520_1", "ru").take(450))
}
