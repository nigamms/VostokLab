$ErrorActionPreference = "Stop"
$version = "9.3.1"
$destination = Join-Path $env:LOCALAPPDATA "VostokLab\gradle-tools"
$gradle = Join-Path $destination "gradle-$version\bin\gradle.bat"
if (-not (Test-Path $gradle)) {
    New-Item -ItemType Directory -Path $destination -Force | Out-Null
    $archive = Join-Path $destination "gradle-$version-bin.zip"
    Write-Host "Downloading official Gradle $version..."
    Invoke-WebRequest -Uri "https://services.gradle.org/distributions/gradle-$version-bin.zip" -OutFile $archive
    Expand-Archive -Path $archive -DestinationPath $destination -Force
    Remove-Item $archive -Force
}
& $gradle @args
exit $LASTEXITCODE
